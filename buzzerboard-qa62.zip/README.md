# Как читать QA-архив BuzzerBoard #62

Проверенный `main` — `ad9db22e2f562e9a72609e3b3830107f1e78ec39`. Распакуйте ZIP и откройте `index.html` для просмотра PNG. `REPORT.md` содержит матрицу, классификацию, выводы и ссылки на CI/deploy. `data` содержит синтетические fixtures, JSON измерений, протокол браузерных проб и проверку анонимного ingress. В production-метаданных сохранён результат перехода к Cloudflare Access. Изображения продукта сняты локально, у Hub подлинные эмблемы загружены по официальным статическим URL через HTTP-клиент Playwright. Все спортивные данные синтетические.

## Воспроизведение

Из отдельного checkout на указанном SHA с Node 22, pnpm и Chromium Playwright.

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm build
pnpm run visual:pro171 --compact
node scripts/pro171-visual.mjs --audit-only
STANDINGS_OUTPUT=/absolute/path/to/new-standings node scripts/issue66-standings-visual.mjs
HUB_OUTPUT=/absolute/path/to/new-hub node scripts/issue70-home-visual.mjs --logo-evidence --playwright-logo-fetch
BB_QA_REPO=/absolute/path/to/checkout BB_QA_OUT=/absolute/path/to/new-probes node /absolute/path/to/unpacked/tools/qa-probes.mjs
```

Вывод `FAIL` в `qa-probes.mjs` означает наблюдаемое отклонение в продукте. `HARNESS_ERROR` означает, что пробу не удалось завершить. Машиночитаемый итог содержит статусы, фактические GET, ошибки браузера, имена связанных PNG и 6 измерений локальной нагрузки. Спортивные запросы в браузерных сценариях перехватываются и подменяются фикстурами. Сетевой режим логотипов разрешает только существующие статические SVG NBA CDN.
