import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import path from 'node:path'

const root = path.resolve(process.env.BB_QA_REPO ?? '/private/tmp/buzzerboard-qa62')
const out = path.resolve(process.env.BB_QA_OUT ?? '/private/tmp/bbqa62/evidence/probes')
const require = createRequire(path.join(root, 'package.json'))
const { chromium } = require('playwright')
const { preview } = await import(require.resolve('vite'))
const fixture = JSON.parse(await readFile(path.join(root, 'scripts/fixtures/nba-hub.synthetic.json'), 'utf8'))
const origin = 'http://127.0.0.1:4189'
const date = fixture.today
const past = '2026-11-23'
const future = '2026-11-25'
const empty = '2026-11-26'
const duration = ms => new Promise(resolve => setTimeout(resolve, ms))
const codeError = code => ({
  error: { code, message: 'QA synthetic response', retryable: true, provider: null, upstreamStatus: null },
  requestId: null,
})
const playerShape = (player) => ({
  ...player, team: null, position: null, number: null, height: null, weight: null, stats: null,
})
const playersMeta = {
  source: 'bbs', seasonEndYear: 2027, fetchedAt: fixture.clock, isStale: false,
  coverage: { providerRows: 2, total: 2, checked: 2, averages: 0, enriched: 0, boxLinks: 0 },
}
const hubRows = page => page.locator('.home-game-list .gc-score-row')
const centerRows = page => page.locator('.gc-scoreboard .gc-score-row')
const tableRows = page => page.locator('.standings-table tbody tr')
const section = page => page.locator('main')
const button = (page, name) => page.getByRole('button', { name, exact: true })
const teamPath = '/teams/BOS'
const title = (page, label) => page.getByRole('heading', { name: label, exact: true })
const texts = loc => loc.allTextContents()
const asURL = uri => new URL(uri, origin)
const records = []
const returnResult = (ok, evidence) => ({ outcome: ok ? 'PASS' : 'FAIL', ...evidence })
const allowed = ['/api/games','/api/standings','/api/players','/api/teams']

await mkdir(out, { recursive: true })
const server = await preview({ root, preview: { host: '127.0.0.1', port: 4189, strictPort: true } })
const browser = await chromium.launch()
async function screenshot(page, name, fullPage = false) {
  await page.evaluate(() => document.fonts.ready)
  await page.screenshot({ path: path.join(out, name + '.png'), animations: 'disabled', fullPage })
}
async function setup(width, height, opts) {
  const ctx = await browser.newContext({
    viewport: { width, height }, locale: 'ru-RU', timezoneId: 'Asia/Nicosia', hasTouch: width < 400,
  })
  const state = { requests: [], responses: [], blocked: [], errors: [], mode: 'normal' }
  await ctx.addInitScript(({ favoriteSeed, spoiler, today }) => {
    if (sessionStorage.getItem('bbqa62-initialized')) return
    sessionStorage.setItem('bbqa62-initialized', '1')
    for (const [key, ids] of Object.entries(favoriteSeed || {}))
      localStorage.setItem('buzzerboard.favorite-' + key + '.v1', JSON.stringify(ids))
    if (spoiler) localStorage.setItem('buzzerboard:spoilers:v1', JSON.stringify({enabled:true, day:today}))
  }, { favoriteSeed: opts.favorites, spoiler: opts.spoiler, today: date })
  await ctx.route(url => url.origin !== origin || url.pathname.startsWith('/api/'), async route => {
    const url = new URL(route.request().url())
    if (url.origin !== origin || route.request().method() !== 'GET') {
      state.blocked.push({ origin: url.origin, method: route.request().method(), kind: route.request().resourceType() })
      return route.abort()
    }
    const req = url.pathname + url.search
    state.requests.push(req)
    const respond = async (status, json) => {
      try {
        await route.fulfill({ status, json })
        state.responses.push({ req, status })
      } catch (error) {
        if (!/aborted|closed|handled|Navigation/i.test(error.message))
          state.errors.push(error.message)
      }
    }
    const selected = url.searchParams.get('date')
    if (url.pathname === '/api/games') {
      const normal = fixture.days[selected]
      if (opts.gameDelay) await duration(opts.gameDelay(selected) || 0)
      if (state.mode === 'offline') return route.abort('internetdisconnected')
      if (state.mode === 'error') return respond(503, codeError('storage_unavailable'))
      if (state.mode === 'quota') return respond(429, codeError('quota_exceeded'))
      if (!normal && !opts.games) return respond(503, codeError('cache_miss'))
      const json = opts.games?.(selected, structuredClone(normal ?? fixture.days[date])) ?? normal
      return respond(200, json)
    }
    if (url.pathname === '/api/standings') {
      if (opts.onlyStandingsError) return respond(503, codeError('cache_miss'))
      return respond(200, opts.standings?.(structuredClone(fixture.standings)) ?? fixture.standings)
    }
    if (url.pathname === '/api/players') {
      if (opts.playersMiss) return respond(503, codeError('cache_miss'))
      return respond(200, { ...playersMeta, players: fixture.players.map(playerShape) })
    }
    if (url.pathname.startsWith('/api/players/')) {
      const id = decodeURIComponent(url.pathname.split('/').at(-1))
      const player = fixture.players.find(entity => entity.id === id)
      if (player) return respond(200, { ...playersMeta, player: playerShape(player), detail: null })
      return respond(404, codeError('not_found'))
    }
    if (url.pathname === '/api/teams') {
      if (opts.teamsMiss) return respond(503, codeError('cache_miss'))
      const data = fixture.standings.data.map(row => ({
        code: row.team.abbreviation, name: row.team.displayName, conference: row.conference, division: 'Atlantic', team: row.team, season: null,
      }))
      return respond(200, { data, coverage: { total:30, available:0 }, meta:fixture.standings.meta })
    }
    if (/^\/api\/teams\/[^/]+$/.test(url.pathname)) return respond(503, codeError('cache_miss'))
    if (/^\/api\/games\/[^/]+$/.test(url.pathname)) {
      const id = decodeURIComponent(url.pathname.split('/').at(-1))
      const snapshot = fixture.days[selected]
      const game = snapshot?.data.find(entity => entity.id === id)
      if (game) return respond(200, { data: {game, boxScore:null}, meta:snapshot.meta, boxScoreMeta:null, boxScoreAvailability:'unavailable' })
    }
    return respond(503, codeError('cache_miss'))
  })
  const page = await ctx.newPage()
  page.setDefaultTimeout(5500)
  page.on('pageerror', e => state.errors.push(e.message))
  page.on('console', message => {
    if (message.type() === 'error' && /invalid time value|cannot format an invalid date/i.test(message.text()))
      state.errors.push(message.text().slice(0, 200))
  })
  if (!opts.realClock) await page.clock.setFixedTime(new Date(opts.clock ?? fixture.clock))
  return {ctx,page,state}
}
async function run(id, opts, fn) {
  const [width,height] = opts.size ?? [375,812]
  const {ctx,page,state} = await setup(width,height,opts)
  let result
  try {
    result = await fn(page, state)
  } catch (error) {
    result = { outcome:'HARNESS_ERROR', message:error.message }
    await screenshot(page,id+'-harness').catch(() => {})
  } finally {
    const files = result?.screenshots || []
    records.push({ id, size:[width,height], ...result, screenshots:files, network:state.requests, responses:state.responses, blocked:state.blocked, browserErrors:state.errors })
    console.log(id,result?.outcome,result?.message?.split('\n')[0] ?? '')
    await ctx.close()
  }
}
const open = (page, uri) => page.goto(origin + uri)
const waitURL = (page, pathname, chosen) =>
  page.waitForURL(url => url.pathname === pathname && url.searchParams.get('date') === chosen)
const noFake = page => page.locator('.gc-scoreboard-numbers, .game-detail-side > strong').count()
const focusVisible = locator => locator.evaluate(el => el === document.activeElement && el.matches(':focus-visible'))
const selectOption = async (page, selector, option) => {
  await page.getByRole('combobox', { name: selector }).click()
  await page.getByRole('option', { name: option, exact: true }).click()
}

try {
  await run('gc-disappearing-team', {size:[375,812]}, async (page,state) => {
    await open(page,'/games?date='+date+'&team=nba%3Ateam%3AMIN')
    await centerRows(page).first().waitFor()
    const start = await centerRows(page).count()
    await button(page,'Следующий день').click()
    await waitURL(page,'/games',future)
    await page.locator('.gc-scoreboard .gc-score-row, .gc-state').first().waitFor()
    await page.getByRole('button',{name:/^Фильтры/}).click()
    const option=await page.getByRole('combobox',{name:'Фильтр по команде'}).innerText()
    const pageRows=await centerRows(page).count()
    const carries=asURL(page.url()).searchParams.get('team')
    const evidence={ start, selectedTeam:option, pageRows, teamInURL:carries, fixtureHasMIN:fixture.days[future].data.some(g=>[g.awayTeam.id,g.homeTeam.id].includes('nba:team:MIN')), emptyState:await page.locator('.gc-state').allTextContents(), screenshots:['gc-disappearing-team.png','gc-disappearing-team-recovered.png'] }
    await screenshot(page,'gc-disappearing-team')
    if (pageRows === 0) await page.locator('.gc-state').getByRole('button',{name:'Сбросить фильтры',exact:true}).click()
    await centerRows(page).first().waitFor()
    evidence.afterReset=await centerRows(page).count()
    await screenshot(page,'gc-disappearing-team-recovered')
    return returnResult(!carries && pageRows > 0,evidence)
  })

  await run('gc-delayed-date-isolation',{gameDelay:d=>d===date?800:20}, async (page,state) => {
    await open(page,'/games?date='+date)
    await button(page,'Следующий день').click()
    await waitURL(page,'/games',future)
    await centerRows(page).first().waitFor()
    const names=await centerRows(page).evaluateAll(rows=>rows.map(row=>row.getAttribute('aria-label')))
    await duration(850)
    const stable=JSON.stringify(names)===JSON.stringify(await centerRows(page).evaluateAll(rows=>rows.map(row=>row.getAttribute('aria-label'))))
    const dates=await page.locator('.gc-scoreboard-result[href]').evaluateAll(links=>links.map(a=>new URL(a.href).searchParams.get('date')))
    await screenshot(page,'gc-delayed-date-isolation')
    return returnResult(stable && dates.length === 5 && dates.every(value=>value===future) && state.requests.includes('/api/games?date='+date),{selected:future,dates,stable,names,screenshots:['gc-delayed-date-isolation.png']})
  })

  await run('gc-offline-refetch',{},async (page,state) => {
    await open(page,'/games?date='+date)
    await centerRows(page).first().waitFor()
    const before=await centerRows(page).count()
    state.mode='offline'
    await button(page,'Обновить данные').click()
    await page.getByText(/Не удалось обновить данные. Показаны последние/).waitFor()
    const after=await centerRows(page).count()
    const message=await page.locator('.gc-notice--warning').innerText()
    await screenshot(page,'gc-offline-refetch')
    await button(page,'Следующий день').click()
    await waitURL(page,'/games',future)
    await title(page,'Не удалось загрузить матчи').waitFor()
    const coldRows=await centerRows(page).count()
    await screenshot(page,'gc-offline-cold-day')
    state.mode='normal'
    await button(page,'Попробовать снова').click()
    await centerRows(page).first().waitFor()
    const restored=await centerRows(page).count()
    return returnResult(before===7 && before===after && coldRows===0 && restored===5,{before,after,coldRows,restored,message,screenshots:['gc-offline-refetch.png','gc-offline-cold-day.png']})
  })

  await run('gc-quota-response',{},async (page,state) => {
    state.mode='quota'
    await open(page,'/games?date='+date)
    await page.locator('.gc-state[role=alert]').waitFor()
    const alert=await page.locator('.gc-state[role=alert]').innerText()
    const requests=state.requests.length
    await duration(350)
    await screenshot(page,'gc-quota-response')
    return returnResult(await noFake(page)===0 && requests===state.requests.length, {alert,requests,quotaExplicit:/квот|лимит/i.test(alert),screenshots:['gc-quota-response.png']})
  })

  await run('gc-invalid-enum-and-nested',{games:(d,s)=>({...s,data:[{...s.data[0],status:'invalid_state',awayTeam:{...s.data[0].awayTeam,displayName:77}}]})},async (page)=>{
    await open(page,'/games?date='+date)
    await page.locator('.gc-state[role=alert]').waitFor()
    const alert=await page.locator('.gc-state[role=alert]').innerText()
    await screenshot(page,'gc-invalid-enum-and-nested')
    return returnResult(await noFake(page)===0,{alert,screenshots:['gc-invalid-enum-and-nested.png']})
  })

  await run('hub-invalid-start-time',{games:(d,s)=>({...s,data:[{...s.data[0],startsAt:'not-a-timestamp'}]})},async (page,state)=>{
    await open(page,'/?date='+date)
    await page.locator('.home-standings .overview-mini-row').first().waitFor()
    await duration(300)
    const rows=await hubRows(page).count()
    const alert=await page.locator('.home-scoreboard [role=alert]').count()
    const timeError=state.errors.some(text=>/Invalid time value|invalid date/i.test(text))
    await screenshot(page,'hub-invalid-start-time')
    return returnResult(alert>0 && !timeError,{rows,alert,timeError,screenshots:['hub-invalid-start-time.png']})
  })

  await run('hub-wrong-game-date-spoiler',{spoiler:true,games:(d,s)=>({...s,data:[{...s.data[0],nbaGameDate:'2026-11-22',status:'final',score:{away:181,home:183},scoreByPeriod:null}]})},async (page)=>{
    await open(page,'/?date='+past)
    await page.waitForFunction(()=>document.querySelector('.home-scoreboard .gc-score-row, .home-scoreboard [role=alert]'))
    const score=await texts(page.locator('.home-scoreboard .gc-scoreboard-numbers'))
    const gameLink=await page.locator('.home-scoreboard .gc-scoreboard-result[href]').first().getAttribute('href').catch(()=>null)
    const aria=await page.locator('.home-scoreboard [aria-label*="181"]').count()
    const gameDate=gameLink ? asURL(gameLink).searchParams.get('date') : null
    const on=await page.getByRole('button',{name:'Без спойлеров',exact:true}).getAttribute('aria-pressed')
    await screenshot(page,'hub-wrong-game-date-spoiler')
    return returnResult(score.length===0 && aria===0 && (!gameDate || gameDate===past),{selected:past,returned:'2026-11-22',gameDate,score,aria,spoilerEnabled:on,screenshots:['hub-wrong-game-date-spoiler.png']})
  })

  await run('hub-invalid-score-domain',{games:(d,s)=>({...s,data:[{...s.data[0],status:'final',score:{away:-15,home:4.5},scoreByPeriod:null}]})},async (page)=>{
    await open(page,'/?date='+date)
    await page.waitForFunction(()=>document.querySelector('.home-scoreboard .gc-score-row, .home-scoreboard [role=alert]'))
    const score=await texts(page.locator('.home-scoreboard .gc-scoreboard-numbers'))
    await screenshot(page,'hub-invalid-score-domain')
    return returnResult(score.length===0,{score,screenshots:['hub-invalid-score-domain.png']})
  })

  await run('hub-invalid-snapshot-meta',{games:(d,s)=>({...s,meta:{...s.meta,fetchedAt:'invalid',rejectedRecords:-2}})},async (page)=>{
    await open(page,'/?date='+date)
    await page.waitForFunction(()=>document.querySelector('.home-scoreboard .gc-score-row, .home-scoreboard [role=alert]'))
    const status=await page.locator('.home-scoreboard .gc-data-status').allTextContents()
    const alerts=await page.locator('.home-scoreboard [role=alert]').count()
    const stale=await page.locator('.home-scoreboard .gc-data-status--stale').count()
    const source=page.locator('.home-scoreboard .gc-source-details summary')
    if(await source.count()) await source.click()
    await screenshot(page,'hub-invalid-snapshot-meta')
    return returnResult(alerts>0 || stale>0,{status,alerts,stale,screenshots:['hub-invalid-snapshot-meta.png']})
  })

  await run('gc-date-limits-and-live-label',{games:(d,s)=>({...s,data:[{
    ...s.data[0],nbaGameDate:d,status:'live',score:{away:null,home:null},scoreByPeriod:null,
  }]})},async (page,state)=>{
    await open(page,'/games?date=2026-11-31')
    await centerRows(page).first().waitFor()
    const label=await centerRows(page).first().locator('.gc-scoreboard-status').innerText()
    const atInvalid=state.requests.at(-1)
    await open(page,'/games?date=2026-10-25')
    await centerRows(page).first().waitFor()
    const min=await button(page,'Предыдущий день').isDisabled()
    await open(page,'/games?date=2026-12-01')
    await centerRows(page).first().waitFor()
    const max=await button(page,'Следующий день').isDisabled()
    await screenshot(page,'gc-date-limits')
    return returnResult(label==='Уточняется'&&min&&max&&atInvalid==='/api/games?date='+date,{label,min,max,atInvalid,screenshots:['gc-date-limits.png']})
  })

  await run('gc-cache-miss-vs-empty',{},async (page)=>{
    await open(page,'/games?date=2026-11-27')
    await page.locator('.gc-state[role=alert]').waitFor()
    const miss=await page.locator('.gc-state[role=alert] h2').innerText()
    await screenshot(page,'gc-cache-miss')
    await open(page,'/games?date='+empty)
    await title(page,'В этот день матчей нет').waitFor()
    const noGames=await page.locator('.gc-state h2').innerText()
    await screenshot(page,'gc-empty')
    return returnResult(/пока нет данных/i.test(miss)&&miss!==noGames,{miss,noGames,screenshots:['gc-cache-miss.png','gc-empty.png']})
  })

  await run('hub-dst-cyprus',{clock:'2026-03-29T01:20:00Z',games:(d,s)=>({...s,data:s.data.slice(0,2).map((g,i)=>({...g,nbaGameDate:d,startsAt:['2026-03-29T00:59:00Z','2026-03-29T01:00:00Z'][i],status:'scheduled',score:{away:null,home:null},scoreByPeriod:null}))})},async (page,state)=>{
    await open(page,'/')
    await hubRows(page).first().waitFor()
    const values=await texts(hubRows(page).locator('time'))
    const subtitle=await page.locator('.home-score-heading p').innerText()
    await screenshot(page,'hub-dst-cyprus')
    return returnResult(values.join(',')==='02:59,04:00'&&state.requests.includes('/api/games?date=2026-03-28'),{values,subtitle,screenshots:['hub-dst-cyprus.png']})
  })

  await run('gc-dst-et-midnight',{clock:'2026-03-08T04:59:00Z',games:(d,s)=>({...s,data:s.data.slice(0,1).map(g=>({...g,nbaGameDate:d,startsAt:'2026-03-08T00:00:00Z'}))})},async (page,state)=>{
    await open(page,'/games')
    await centerRows(page).first().waitFor()
    await page.clock.setFixedTime(new Date('2026-03-08T05:00:00Z'))
    await page.evaluate(()=>window.dispatchEvent(new Event('focus')))
    await page.waitForFunction(()=>document.querySelector('.gc-scoreboard-result[href]')?.href.includes('date=2026-03-08'))
    const url=await centerRows(page).first().locator('.gc-scoreboard-result[href]').getAttribute('href')
    await screenshot(page,'gc-dst-et-midnight')
    return returnResult(state.requests.includes('/api/games?date=2026-03-07')&&state.requests.includes('/api/games?date=2026-03-08'),{url,screenshots:['gc-dst-et-midnight.png']})
  })

  await run('standings-sort-eight', {size:[1440,900], standings:s=>{
    for (const row of s.data.filter(r=>['WAS','SAS'].includes(r.team.abbreviation)))
      row.record.averageMargin=null
    return s
  }}, async (page)=>{
    await open(page,'/standings')
    await tableRows(page).first().waitFor()
    const table=page.locator('.standings-table')
    const buttons=table.locator('thead .sort-button')
    const results=[]
    const conferenceSwitch=label=>page.getByRole('button',{name:new RegExp('^'+label)})
    for (const conference of ['Восток','Запад']) {
      await conferenceSwitch(conference).click()
      const rowCount=await tableRows(page).count()
      const code = conference==='Восток' ? 'WAS' : 'SAS'
      const metricByCol=[
        r=>r.record.wins, r=>r.winPercentage, r=>{
          const leader=fixture.standings.data.filter(e=>e.conference===r.conference).sort((a,b)=>b.winPercentage-a.winPercentage)[0]
          return (leader.record.wins-r.record.wins+r.record.losses-leader.record.losses)/2
        },
        r=>r.record.homeWins,r=>r.record.awayWins,r=>r.record.conferenceWins,r=>r.record.lastTenWins,r=>r.team.abbreviation===code?null:r.record.averageMargin,
      ]
      const expectedRows=fixture.standings.data.filter(row=>row.conference===(conference==='Восток'?'east':'west'))
      for(let index=0;index<await buttons.count();index++) {
        const btn=buttons.nth(index)
        for(let i=0;i<2;i++){
          await btn.click()
          const sorted=await table.locator('th[aria-sort]').getAttribute('aria-sort')
          const order=await tableRows(page).locator('.team-profile-link').evaluateAll(links=>links.map(a=>a.getAttribute('href')?.split('/').at(-1)))
          const by=metricByCol[index]
          const expected=[...expectedRows].sort((a,b)=>{
            const x=by(a), y=by(b)
            if (x===null&&y!==null) return 1
            if (x!==null&&y===null) return -1
            if (x!==null&&y!==null&&x!==y) return (x-y)*(sorted==='ascending'?1:-1)
            return a.team.displayName.localeCompare(b.team.displayName,'en')
          }).map(r=>r.team.abbreviation)
          results.push({conference,col:index,sorted,rowCount,correct:JSON.stringify(order)===JSON.stringify(expected),first:order[0],last:order.at(-1)})
        }
      }
    }
    const directionsAreBoth=[...new Set(results.map(r=>r.conference+' '+r.col))].every(k=>new Set(results.filter(r=>r.conference+' '+r.col===k).map(r=>r.sorted)).size===2)
    await screenshot(page,'standings-sort-eight')
    return returnResult(results.length===32&&directionsAreBoth&&results.every(r=>r.correct&&r.rowCount===15),{results,screenshots:['standings-sort-eight.png']})
  })

  await run('standings-wrong-season',{standings:s=>({...s,data:s.data.map(r=>({...r,seasonEndYear:2026}))})},async(page)=>{
    await open(page,'/standings')
    await page.waitForFunction(()=>document.querySelector('.standings-table tbody tr, .standings-center [role=alert]'))
    const rows=await tableRows(page).count()
    const season=await page.locator('.standings-season').innerText()
    const first=rows?await tableRows(page).first().innerText():null
    const warning=await page.locator('.standings-gb-warning').allTextContents()
    await screenshot(page,'standings-wrong-season',true)
    await open(page,'/')
    await page.locator('.home-standings .gc-state').waitFor()
    const hubRows=await page.locator('.home-standings .overview-mini-row').count()
    await screenshot(page,'hub-wrong-season',true)
    return returnResult(rows===0,{expectedSeason:2027,returnedSeason:2026,displayedSeason:season,rows,first,warning,hubRows,screenshots:['standings-wrong-season.png','hub-wrong-season.png']})
  })

  await run('standings-invalid-pct',{standings:s=>{
    const bad=s.data.find(row=>row.team.abbreviation==='WAS')
    bad.winPercentage=1.42
    return s
  }},async(page)=>{
    await open(page,'/standings')
    await page.waitForFunction(()=>document.querySelector('.standings-table tbody tr, .standings-center [role=alert]'))
    const rows=await tableRows(page).count()
    const first=rows?await tableRows(page).first().innerText():null
    const shown=rows?await tableRows(page).first().locator('td').allTextContents():[]
    const metadata=await page.locator('.gc-data-status').allTextContents()
    await screenshot(page,'standings-invalid-pct',true)
    return returnResult(!first||!/Washington Wizards/i.test(first),{rows,first,shown,metadata,screenshots:['standings-invalid-pct.png']})
  })

  await run('standings-invalid-counter',{standings:s=>{
    s.data[0].record.wins=-1
    return s
  }},async(page)=>{
    await open(page,'/standings')
    await page.locator('.standings-center [role=alert]').waitFor()
    const text=await page.locator('.standings-center [role=alert]').innerText()
    await screenshot(page,'standings-invalid-counter')
    return returnResult(await tableRows(page).count()===0,{text,screenshots:['standings-invalid-counter.png']})
  })

  await run('favorites-navigation-reload',{},async(page,state)=>{
    await open(page,'/teams')
    await page.getByRole('button',{name:'Добавить Boston Celtics в избранное'}).click()
    await page.reload()
    const savedTeam = page.getByRole('button',{name:/Убрать Boston Celtics из избран/})
    await savedTeam.waitFor()
    const savedTeamLabel = await savedTeam.getAttribute('aria-label')
    await open(page,'/players')
    await page.getByRole('button',{name:'Избранное: Ethan Clarke',exact:true}).click()
    await page.reload()
    const savedPlayer=await page.getByRole('button',{name:'Избранное: Ethan Clarke',exact:true}).getAttribute('aria-pressed')
    await open(page,'/?date='+date)
    await hubRows(page).first().getByRole('button',{name:'Добавить матч в избранное'}).click()
    await page.reload()
    const savedGame=await hubRows(page).first().getByRole('button',{name:'Убрать матч из избранного'}).getAttribute('aria-pressed')
    await open(page,'/favorites?tab=teams')
    await page.getByRole('link',{name:'Boston Celtics',exact:true}).first().waitFor()
    await screenshot(page,'favorites-navigation-reload')
    const storage=await page.evaluate(()=>Object.fromEntries(['teams','players','games'].map(kind=>[
      kind,JSON.parse(localStorage.getItem('buzzerboard.favorite-'+kind+'.v1')||'[]'),
    ])))
    return returnResult(savedGame==='true'&&savedPlayer==='true'&&storage.teams.includes('nba:team:BOS')&&storage.games.length===1&&storage.players.length===1,{savedGame,savedPlayer,savedTeamLabel,storage,screenshots:['favorites-navigation-reload.png']})
  })

  await run('catalog-and-news-fallback',{teamsMiss:true,playersMiss:true},async(page,state)=>{
    await open(page,'/teams')
    await page.locator('main [role=alert]').waitFor()
    const teamAlert=await page.locator('main [role=alert]').innerText()
    const teamCount=await page.locator('main a[href^="/teams/"]').count()
    await screenshot(page,'teams-catalog-cache-miss',true)
    await open(page,teamPath)
    await page.getByRole('heading',{name:/Boston Celtics/}).first().waitFor()
    await screenshot(page,'team-profile-cache-miss')
    await open(page,'/players')
    await page.locator('main [role=alert], main .gc-state').first().waitFor()
    const playersFallback=await page.locator('main .gc-state').first().innerText()
    await screenshot(page,'players-cache-miss')
    const n=state.requests.length
    await open(page,'/news')
    await page.getByText('Лента новостей пока недоступна').waitFor()
    const newsInputs=await section(page).getByRole('searchbox').count()
    await screenshot(page,'news-placeholder')
    return returnResult(teamAlert.length>0&&state.requests.length===n&&newsInputs===0,{teamCount,teamAlert,playersFallback,newsRequests:state.requests.length-n,newsInputs,screenshots:['teams-catalog-cache-miss.png','team-profile-cache-miss.png','players-cache-miss.png','news-placeholder.png']})
  })

  await run('details-box-unavailable-and-home-return',{size:[375,812]},async(page,state)=>{
    await open(page,'/?date='+date)
    const link=hubRows(page).first().locator('.gc-scoreboard-result[href]')
    await link.waitFor()
    const from=asURL(await link.getAttribute('href')).searchParams.get('from')
    await link.click()
    await page.locator('.game-details-view').waitFor()
    await page.waitForFunction(()=>document.querySelector('.game-detail-side, .game-details-view .gc-state'))
    const body=await page.locator('.game-details-view').innerText()
    await screenshot(page,'details-box-unavailable')
    await page.locator('.game-detail-back').click()
    await waitURL(page,'/',date)
    return returnResult(from==='/?date='+date&&/статистик|бокс|box.score/i.test(body)&&state.requests.some(path=>path.startsWith('/api/games/')),{from,noBoxText:body.split('\n').filter(l=>/статистик|бокс|box.score/i.test(l)).slice(0,8),screenshots:['details-box-unavailable.png']})
  })

  await run('standings-keyboard-320',{size:[320,600]},async(page)=>{
    await open(page,'/standings')
    await tableRows(page).first().waitFor()
    const region=page.locator('.standings-scroll')
    await region.focus()
    await page.keyboard.press('ArrowRight')
    await duration(250)
    const geometry=await region.evaluate(e=>({client:e.clientWidth,scroll:e.scrollWidth,x:e.scrollLeft,doc:document.documentElement.scrollWidth}))
    const focus=await focusVisible(region)
    await screenshot(page,'standings-keyboard-320')
    return returnResult(geometry.doc===320&&geometry.scroll>geometry.client&&geometry.x>0&&focus,{geometry,focus,screenshots:['standings-keyboard-320.png']})
  })

  for (const [key,width,height] of [['320',320,600],['375',375,812],['768',768,1024],['1440',1440,900],['1920',1920,1080]]) {
    await run('hub-viewport-'+key,{size:[width,height],favorites:fixture.favorites},async(page,state)=>{
      await open(page,'/')
      await hubRows(page).last().waitFor()
      await page.locator('.home-standings .overview-mini-row').first().waitFor()
      await page.evaluate(()=>document.fonts.ready)
      const size=await page.evaluate(()=>{
        const nav=document.querySelector('.gc-mobile-nav')?.getBoundingClientRect().top||innerHeight
        const rows=[...document.querySelectorAll('.home-game-list .gc-score-row')].map(e=>e.getBoundingClientRect())
        const controlClasses=['.home-dates button','.home-game-filters [role=combobox]','.home-game-list .gc-scoreboard-favorite','.home-game-list .gc-scoreboard-result','.home-scoreboard .gc-source-details summary']
        const minTargets=Object.fromEntries(controlClasses.map(selector=>[selector,
          Math.min(...[...document.querySelectorAll(selector)].map(e=>Math.min(e.getBoundingClientRect().width,e.getBoundingClientRect().height))),
        ]))
        return {docWidth:document.documentElement.scrollWidth, firstRowY:Math.round(rows[0].top*10)/10, full:rows.filter(r=>r.bottom<=Math.min(nav,innerHeight)).length,minTargets}
      })
      await screenshot(page,'hub-'+key)
      if (key==='1920') await screenshot(page,'hub-1920-full',true)
      const expected = width===320?2:5
      const reads = [...state.requests].sort()
      return returnResult(size.docWidth===width&&size.full>=expected&&reads.join(',')===['/api/games?date='+date,'/api/standings?seasonEndYear=2027'].join(','),{...size,screenshots:key==='1920'?['hub-1920.png','hub-1920-full.png']:['hub-'+key+'.png']})
    })
  }

  const performance=[]
  for (const [width,height] of [[375,812],[1440,900]]) {
    for(let repeat=1;repeat<=3;repeat++){
      const {ctx,page,state}=await setup(width,height,{
        realClock:true,
        games:(selected,s)=>({...s,data:s.data.length?s.data:fixture.days[date].data.map(g=>({...g,nbaGameDate:selected}))}),
      })
      try {
        await open(page,'/?date='+date)
        await hubRows(page).first().waitFor()
        await page.locator('.home-standings .overview-mini-row').first().waitFor()
        const observed=await page.evaluate(()=>{
          const resources=performance.getEntriesByType('resource')
          const navigation=performance.getEntriesByType('navigation')[0]
          const number=x=>Math.round(x)
          return {
            navResponseStartMs:navigation?number(navigation.responseStart):null,
            paintMs:Object.fromEntries(performance.getEntriesByType('paint').map(value=>[value.name,number(value.startTime)])),
            screenshotReadinessMs:number(performance.now()),
            localJsDecodedBytes:resources.filter(resource=>new URL(resource.name).origin===location.origin&&new URL(resource.name).pathname.endsWith('.js')).reduce((sum,resource)=>sum+resource.decodedBodySize,0),
            localResources:resources.filter(resource=>new URL(resource.name).origin===location.origin).length,
          }
        })
        performance.push({width,height,repeat,...observed,workerGET:state.requests})
      } finally {await ctx.close()}
    }
  }

  const output={
    head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
    browserVersion:browser.version(),timezone:'Asia/Nicosia',
    originKind:'local Vite preview of production build with synthetic Worker response routes; non-local requests aborted',
    unexpectedNetwork: records.flatMap(r=>r.network).filter(p=>!allowed.some(base=>p.startsWith(base))),
    records, performance,
  }
  await writeFile(path.join(out,'probe-results.json'),JSON.stringify(output,null,2)+'\n')
} finally {
  await browser.close()
  await new Promise(resolve=>server.httpServer.close(resolve))
}
