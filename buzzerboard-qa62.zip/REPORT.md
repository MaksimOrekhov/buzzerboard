# BuzzerBoard MVP · End-to-End QA #62

**Результат.** Пройден браузерный аудит актуального `main` на синтетических данных. В 26 дополнительных сценариях на собранном Vue получено **19 PASS, 7 FAIL**. Среди воспроизведённых отклонений 4 P1 и 3 P2. P0 не выявлено в проверенных сценариях. Подтверждён deploy того же SHA и анонимный редирект Cloudflare Access. Авторизованные production UI/API, свежесть результатов и натуральный цикл остаются **NOT VERIFIED**. [ТЗ QA](https://github.com/MaksimOrekhov/buzzerboard/issues/62#issuecomment-7159175411)

Проверенный SHA **`ad9db22e2f562e9a72609e3b3830107f1e78ec39`**, merge PR #73. За основу взят свежий `main`, содержащий NBA Hub A, восстановление эмблем, Standings A, Game Center Scoreboard A и Game Details. QA выполнен без изменений продуктового кода, ветки main, флагов, расписания или production. За QA было **0 вызовов BBS/DunkAPI и 0 дополнительных provider-кредитов**. Синтетические снимки и тесты лежат в архиве. [PR #73](https://github.com/MaksimOrekhov/buzzerboard/pull/73) · [Проверенный коммит](https://github.com/MaksimOrekhov/buzzerboard/commit/ad9db22e2f562e9a72609e3b3830107f1e78ec39)

## Production и CI

| Среда / проверка | Результат | Доказательство |
|---|---|---|
| GitHub Actions на push в main | **PASS**, `Verify app`, `Standings visual evidence`, `NBA Hub visual evidence` | [CI 45613909568](https://github.com/MaksimOrekhov/buzzerboard/actions/runs/45613909568), `data/ci-main.json` |
| Cloudflare release на этом SHA | **PASS**, шаг `Deploy Worker and static assets` завершён успешно | [Deploy 45615305362](https://github.com/MaksimOrekhov/buzzerboard/actions/runs/45615305362), `data/deploy-main.json` |
| Анонимный production GET | **PASS**, `/`, `/games`, `/standings`, `/favorites`, `/api/health` вернули 302 в Cloudflare Access. Записаны статус, сервер и путь редиректа без query. Первый запрос без явного UA получил 403. Источник первого отказа не атрибутирован | `data/production-ingress.json` |
| Авторизованный production GET / браузер | **NOT VERIFIED**, сессия владельца недоступна в окружении аудита | За Access не выполнялись переходы, API ответов не получено |
| Натуральный Cron, D1, quota и SLA #43/#46 | **NOT VERIFIED** | Deploy не удостоверяет выполнение Cron или содержание D1 |

Для окна **25.11.2026, 12:30–13:00 Asia/Nicosia** контрольная дата «вчера» — **24.11.2026 NBA ET**. Production final/total, fetchedAt, возраст D1, позиция очереди, факт Cron, CPU/ошибки и расход/остаток quota **не наблюдались**. Исторические 7/7 Scheduled из #43 относятся к более раннему наблюдению, а локальные финалы синтетические. [#43](https://github.com/MaksimOrekhov/buzzerboard/issues/43) · [#46](https://github.com/MaksimOrekhov/buzzerboard/issues/46)

## Функциональная матрица

| Область | Локально с fixtures | CI synthetic текущего main | Авторизованный production |
|---|---|---|---|
| NBA Hub | **PASS** · день NBA, календарь, reload/Back/Forward, Game Center и возврат из деталей, ID-only «Мои матчи», отсутствие матчей, статусы и избранное. 320/375/768/1440 и дополнительный 1920 | **PASS** · существующий прогон Hub | **NOT VERIFIED** |
| Эмблемы #73 | **PASS** · 16 мест в трёх секциях, в т.ч. BOS/CHI/LAL/MIN. Chromium декодировал подлинные SVG, полученные с официального CDN тем же HTTP-клиентом Playwright. Смоделированы abort и HTTP 503. Спортивные данные синтетические | **PASS** · попытки загрузки и fallback при блокировке исходящих ресурсов | **NOT VERIFIED** |
| Game Center даты и cache | **PASS** · прошлое/сегодня/будущее, отдельный cache miss, календарь и границы −30/+7. Задержка предыдущего ответа 800 мс не испортила выбранный день. Вчерашний фокус делает cache-only GET по правилам. Live enum виден как «Уточняется» | **PASS** · браузерный smoke, календарь, вчерашние, отмена и статус | **NOT VERIFIED** |
| Даты DST | **PASS** · 29.03 на Кипре 02:59 → 04:00 при NBA ET 28.03, 08.03 смена NBA ET 07 → 08 марта между 04:59 и 05:00 UTC. US/Cyprus boundary также покрыты unit | **PASS** · unit | **NOT VERIFIED** |
| Game Center фильтры | **PASS** · статус, команда, favorites и reset. **FAIL** · отсутствующая команда остаётся при смене даты (QA-06) | **PASS** · стандартные фильтры. Этот кейс отдельно CI не покрывает | **NOT VERIFIED** |
| Game Details | **PASS** · переход из Home/Game Center/Favorites, параметры date/from, возврат, якоря, final/scheduled/unknown, полный box score/данные игроков, fallback без box score и ошибки. Неполные метрики/несогласованный box проверены существующими тестами/fixtures | **PASS** · unit и браузерные сценарии | **NOT VERIFIED** |
| Standings корректного сезона | **PASS** · Восток/Запад, все 8 сортировок в обе стороны на обеих конференциях (32 проверки реального DOM), null-last, GB у валидного полного снимка, отказ от GB при 8/15, равном PCT или противоречии W–L/PCT. Нет выдуманного rank, корректны сравнения BOS–LAL/CHI–MIN и Escape/focus | **PASS** · Standings A | **NOT VERIFIED** |
| Валидация | **PASS** · невалидный nested Team/enum и отрицательный standings counter дают ошибку без счёта или таблицы. **FAIL** · несовпадение NBA-даты, startsAt, очки и metadata, сезон/PCT (QA-01–05, QA-07) | **PASS** · текущие guards и нормализации в unit. Новые негативные кейсы отсутствуют в CI | **NOT VERIFIED** |
| Отказы и свежесть | **PASS** · loading, empty, cache_miss, schema error, 503, stale/refreshError. Offline-отказ при refetch оставил 7 игр и предупреждение, новый день показал ошибку без результатов, повтор восстановил 5. Синтетический 429 не запустил автоматические повторы | **PASS** · стандартные состояния. Отдельные offline/429 пробы локальные | **NOT VERIFIED** |
| Favorites | **PASS** · отдельно сохранены команда, игрок и матч, состояние сохраняется после reload и открывается в Favorites. Ссылки сохраняют контекст даты матча | **PASS** · favorites и навигация | **NOT VERIFIED** |
| Teams, Players, Encyclopedia | **PASS** · каталоги, профиль команды/вкладки, игрок/профиль, арены/города и связь карточки игры, джерси/WebGL и 2D fallback, обработка unavailable snapshots. Доступные статические ресурсы проверены локально; синтетические отсутствующие данные не заменены выдуманными | **PASS** · 15 типов маршрутов и существующие дополнительные browser-проверки | **NOT VERIFIED** |
| News | **PASS** · честная заглушка, 0 API GET на открытие. Реальные новости/RSS и фильтры **NOT VERIFIED**, фича в #57 | **PASS** · страница заглушки | **NOT VERIFIED** |
| Spoiler Mode | **PASS** · нормальные fixtures проверены на Home, Game Center, Details, Standings, team/player и Favorites. Защищённые значения отсутствуют в DOM/ARIA, контролируемое раскрытие, вчерашний scheduled и будущий ошибочный final, игры защищены и при настоящих эмблемах. **FAIL** · смещённая дата в ответе обходит область защиты (QA-01) | **PASS** · существующий сценарий Spoiler. Дефект QA-01 не покрыт | **NOT VERIFIED** |
| Визуал и клавиатура | **PASS** · 4 обязательных viewport и 1920 для Hub, реальные PNG открыты, body overflow отсутствует в проверенных сценариях, внутренняя таблица scrollable с клавиатуры, фокус календаря/сравнения. Наблюдение по мелким контролам ниже | **PASS** · штатная матрица 320–1440 и адаптивные states | **NOT VERIFIED** |

Локально прошли `pnpm test` (**373 Vitest + 18 Node**) и `pnpm build`. Действия проверялись в собранном Vue через локальный Vite preview и Chromium 159 с Playwright, locale ru-RU, Asia/Nicosia. Штатные `pro171`, `issue66` и `issue70` использованы для состояний и общей поверхности. Отдельные пробы включают управляемую задержку, ошибку сети, консоль Vue, историю, клавиатуру, проверки DOM и снимки. Физические устройства, screen reader, Safari/Firefox и ручная оценка всех юр. условий в прогон не входили. [Проверенный CI](https://github.com/MaksimOrekhov/buzzerboard/actions/runs/45613909568) · [News #57](https://github.com/MaksimOrekhov/buzzerboard/issues/57)

## Воспроизведённые проблемы

P1 затрагивает целостность основных данных, рендер матча или блокировку результатов. P2 затрагивает сценарий, сортировку или диагностику при наличии обхода. Все семь наблюдений ниже воспроизведены на **synthetic GET**, их проявление с production cache не установлено. Путь к точной пробе и шаги есть в `tools/qa-probes.mjs` и `data/probe-results.json`.

| ID | Приоритет | Воспроизведение и ожидание | Фактическое поведение и доказательство |
|---|---|---|---|
| QA-01 | **P1** · дата и Spoiler | С открытым Spoiler Mode открыть `/?date=2026-11-23`. Смоделировать HTTP 200 со строкой `nbaGameDate=2026-11-22` и final 181:183. Ответ другой даты следует отклонить | Счёт появляется визуально и в двух ARIA-атрибутах. Ссылка уходит на 22.11, заголовок показывает 23.11. `hub-wrong-game-date-spoiler.png` |
| QA-02 | **P1** · выбытие строк | В одной валидной игре передать `startsAt="not-a-timestamp"`, открыть Home. Ожидается fallback времени или понятная ошибка | Счётчик «1 матчей», 0 строк, нет alert. Консоль `RangeError: Invalid time value`, таблица рядом работает. `hub-invalid-start-time.png` |
| QA-03 | **P1** · неверный итог | При final передать числовые очки `-15` и `4.5`. Ожидаются неотрицательные целочисленные значения или отказ | Home показывает **−15:4,5** как результат завершённой игры. `hub-invalid-score-domain.png` |
| QA-04 | **P1** · сезон таблицы | Запросить standings 2027, вернуть 15 East с `seasonEndYear=2026`. Ожидается отказ или корректная маркировка | Полная таблица показывает 15 строк под «2026/27», блок GB отключён, причина несоответствия заменена общим предупреждением W–L/PCT. Мини-таблица Home исключает те же строки. `standings-wrong-season.png`, `hub-wrong-season.png` |
| QA-05 | **P2** · сортировка PCT | В East у WAS (4–15) выставить `PCT=1.42`. Ожидается отказ или невалидный PCT в конце | PCT отрисовывается как «—», но WAS занимает первую строку в порядке по PCT. GB корректно отключается. `standings-invalid-pct.png` |
| QA-06 | **P2** · фильтр при смене даты | Открыть `/games?date=2026-11-24&team=nba%3Ateam%3AMIN`, нажать следующий день. В новом снимке 5 игр без MIN. ТЗ ожидает сброс отсутствующего фильтра | MIN остаётся в URL и селекте, видно 0/5. Ручной сброс восстанавливает пять матчей. `gc-disappearing-team.png`, `gc-disappearing-team-recovered.png` |
| QA-07 | **P2** · metadata | В ответе игр оставить нормальные строки, задать `fetchedAt="invalid"`, `rejectedRecords=-2`. Ожидается отказ или явная диагностическая деградация | Обычный зелёный индикатор, «время не указано», внутри источника «Отклонено записей: -2». Нет alert/stale. `hub-invalid-snapshot-meta.png` |

По исходникам `fetchGamesForDate` проверяет целостность списка базовым guard без проверки даты каждой игры. `fetchGameDetails` сравнивает дату с запросом. `isGameRecord` проверяет календарную строку и enum, но для startsAt требует строку, а для очков — конечное число. Строгость HTTP 200 к метаданным Game Center ограничена типами. Guard standings проверяет неотрицательные integer counters, но допускает конечный PCT вне 0–1 и год, который отличается от запроса. Сортировка использует сырой PCT, форматтер отбрасывает невалидное значение. `useGamesForDate.queryFn` использует дату из `queryKey`, `useStandings.queryFn` — замыкание на `currentSeason.value`. В имеющихся UI-вызовах сезон фиксирован в 2027; наблюдаемой гонки смены сезона в интерфейсе нет. [Game API](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/src/features/games/api.ts) · [Game guards](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/src/shared/api/nba/gameDetailsGuards.ts) · [Standings API](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/src/features/standings/api.ts) · [Standings query](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/src/features/standings/composables/useStandings.ts)

Дополнительные P2-наблюдения вне счёта семи проб. Информационная кнопка источника на Home имеет высоту 22 px против целевых 44 px; измеренные основные кнопки дат/фильтров/избранного — 44 px, а клавиатурный скролл таблицы работает. При 429 экран показывает общую ошибку соединения, явной диагностики лимита нет. У Teams после сохранения работает reload, но доступная строка звучит «Убрать Boston Celtics из избранное». Артефакты — `data/probe-results.json`, `gc-quota-response.png`.

## Визуал и производительность

| Viewport | Первый полный матч, верх y | Полные матчи до нижнего меню | Ширина документа |
|---|---:|---:|---:|
| 320×600 | 337,2 | 2 | 320 |
| 375×812 | 337,2 | 5 | 375 |
| 768×1024 | 366 | 5 | 768 |
| 1440×900 | 372,5 | 5 | 1440 |
| 1920×1080 | 380,5 | 5 | 1920 |

В `png/hub` есть прямые viewport, full-page и fallback с логотипами/инициалами. В `png/standings` — режим сравнения, partial, stale и закрытая таблица. `png/routes` содержит представительные экраны общего sweep, а `png/probes` — целевые диагностики. Проверка ширины общего набора в 8 конфигурациях с 15 типами маршрутов не выявила горизонтального overflow страницы. На 320 x таблица шириной 637 px осталась во внутренней области 296 px и прокрутилась на 40 px от ArrowRight с сохранением фокуса.

| Холодный viewport, по 3 прогона | FCP, медиана / диапазон | До обеих готовых секций, медиана / диапазон | Локальный JS после декодирования |
|---|---:|---:|---:|
| 375×812 | 40 мс / 40–40 | 108 мс / 105–108 | 374 737 Б |
| 1440×900 | 40 мс / 36–40 | 101 мс / 98–108 | 374 737 Б |

Каждая холодная навигация на Home отправила два существующих GET — игры выбранной даты и standings 2027. Каталог игроков подгружается в соответствующем сценарии. News не инициирует GET. Сессии чистые, сетевого/CPU throttling нет. Время до двух готовых блоков измерено после ожиданий селекторов Playwright и содержит их накладные расходы. Это замеры локальной сборки c искусственными ответами, не Web Vitals production и не SLA.

## Границы данных, quota и дальнейшее решение

Текущий `wrangler.jsonc` задаёт BBS как источник игр/таблицы, `BBS_REFRESH_ENABLED=true` и Cron `*/10 * * * *`. `BBS_PLAYER_REFRESH_ENABLED=false`, DunkAPI refresh/box refresh выключены. Локальный потолок приложения BBS — 150 запросов/день, резерв 25, 10/мин; доступная часть по конфигу 125/день. Остаток реального ключа/аккаунта и CPU натурального цикла не установлены. В историческом DunkAPI spike использовано 27 из разрешённых 30 кредитов, это запись прежнего теста без текущего запроса баланса. Описания bootstrap, где ещё сказано «Cron отключён», относятся к прежнему состоянию. [Текущий Wrangler](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/wrangler.jsonc) · [Исторический DunkAPI spike](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/docs/dunkapi-spike.md) · [#48](https://github.com/MaksimOrekhov/buzzerboard/issues/48)

Клиент обращается к same-origin Worker, upstream ключи используются сервером. Поддержка отдельного cross-origin клиента и живые CORS-политики upstream не проверялись. Cache GET в исходниках не вызывает provider refresh. Обслуживание истёкшего кэша в Worker может вызвать `deleteCache` на чтении, поэтому для строго беззаписного разбора production данные лучше проверять разрешёнными метриками/логами или D1 SELECT владельца. Лицензирование публичного распространения статистики и NBA-брендинга остаётся открытым. [Worker](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/src/server/worker.ts) · [Access и права](https://github.com/MaksimOrekhov/buzzerboard/blob/ad9db22e2f562e9a72609e3b3830107f1e78ec39/docs/cloudflare-pro169.md) · [#50](https://github.com/MaksimOrekhov/buzzerboard/issues/50)

Перед решением о готовности к выпуску нужны отдельная приёмка P1, журнал разрешённого production smoke и одна-две естественные контрольные точки #43/#46. P2 можно проверять по готовым репро после решения владельца о порядке работ.
