# BuzzerBoard · дизайн профиля игрока · Issue #81

Распакуйте архив и откройте `index.html` в Chromium или другом современном браузере с включённым JavaScript. Локальный сервер и подключение к интернету не требуются.

- `a/index.html` — Player Analytics / Scoreboard.
- `b/index.html` — Player Dashboard.
- `index.html` — список сценариев обоих вариантов. Для состояния загрузки добавьте `&hold=1`, чтобы зафиксировать скелетон.
- `evidence/gallery.html` — сравнения и ссылки на все 68 PNG.
- `REPORT.md` — измерения, trade-offs и рекомендация.
- `METRICS.md` и `evidence/metric-map.csv` — карта всех 32 показателей.
- `evidence/*-measurements.json` и `evidence/interactions.json` — результаты Chromium.
- `assets/fixtures.json` — синтетические снимки, валидированные текущим `isPlayerResponse`. Файл `fixtures.js` загружает те же данные офлайн.
- `shots/baseline` — снимки неизменённой Vue-страницы свежего main. `shots/a` и `shots/b` — исходные файлы каждого концепта без масштабирования сравнительной галереи.

График, сортировка, вкладки, сведения о свежести, избранное и две области Spoiler Mode интерактивны. Ссылки на остальные маршруты открывают локальные экраны контекста с точными идентификаторами из фикстур. Подлинные производственные данные и фотографии в архив не входят. Используется локальная копия Manrope с лицензией OFL в `assets/fonts/OFL.txt` и иконки из исходного BuzzerBoard.

Для повторного запуска тестов подготовьте отдельный checkout SHA `e0f2b7bf5ac83ae39478081f8c6385d824278f30`, установите зависимости по lockfile, выполните `pnpm build` и установите Chromium через `pnpm exec playwright install chromium`. Затем запустите скрипты из `evidence/tools`:

```sh
BB81_REPO=/path/to/buzzerboard node evidence/tools/baseline.mjs
BB81_PACKAGE=/path/to/buzzerboard/package.json node evidence/tools/prototype-qa.mjs
```

Оба прогона блокируют внешние запросы. Baseline отдаётся с локального Vite Preview и использует тот же `PlayerResponse`, что и A/B.
