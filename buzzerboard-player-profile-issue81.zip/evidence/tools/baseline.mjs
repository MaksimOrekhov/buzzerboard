import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { readFile, writeFile, mkdir } from 'node:fs/promises'

const root=process.env.BB81_REPO
if(!root) throw new Error('Set BB81_REPO to the baseline checkout')
const base=process.env.BB81_DELIVERY || fileURLToPath(new URL('../../',import.meta.url)).replace(/\/$/,'')
const require=createRequire(root+'/package.json')
const { chromium }=require('playwright')
const { preview }=await import(require.resolve('vite'))
const fixture=JSON.parse(await readFile(base+'/assets/fixtures.json','utf8'))
const origin='http://127.0.0.1:4199'
const out=base+'/shots/baseline'
const records=[]
await mkdir(out,{recursive:true})
const server=await preview({root,preview:{host:'127.0.0.1',port:4199,strictPort:true}})
const browser=await chromium.launch()
try {
 for (const [width,height] of [[1440,900],[768,1024],[375,812],[320,600]]) {
  const context=await browser.newContext({viewport:{width,height},locale:'ru-RU',timezoneId:'Asia/Nicosia'})
  const requests=[]
  await context.route(url=>url.origin!==origin||url.pathname.startsWith('/api/'),route=>{
    const url=new URL(route.request().url())
    if(url.origin!==origin) return route.abort()
    requests.push({url:url.pathname+url.search,method:route.request().method()})
    if(route.request().method()==='GET'&&decodeURIComponent(url.pathname)==='/api/players/'+fixture.snapshots.default.player.id)
      return route.fulfill({json:fixture.snapshots.default})
    return route.abort()
  })
  const page=await context.newPage()
  await page.clock.setFixedTime(new Date(fixture.now))
  await page.goto(origin+'/players/'+encodeURIComponent(fixture.snapshots.default.player.id))
  await page.locator('.player-log tbody tr').last().waitFor()
  await page.evaluate(()=>document.fonts.ready)
  const metrics=await page.evaluate(()=>{
    const round=x=>Math.round(x*10)/10
    const bounds=el=>{if(!el)return null;const r=el.getBoundingClientRect();return {top:round(r.top+scrollY),bottom:round(r.bottom+scrollY),width:round(r.width),height:round(r.height)}}
    const get=s=>document.querySelector(s)
    const nav=get('.gc-mobile-nav')
    const fold=nav&&nav.getBoundingClientRect().height?nav.getBoundingClientRect().top:innerHeight
    const kpis=[...document.querySelectorAll('.player-kpis')]
    const targets=Object.fromEntries(Object.entries({
      favorite:'.player-profile-heading button',back:'.player-center > a',spoiler:'.gc-topbar button',
      trend:'.player-panel .ui-segmented button',sort:'.player-log th button',game:'.player-log tbody a',
    }).map(([k,s])=>[k,bounds(get(s))]))
    return {fold,documentWidth:document.documentElement.scrollWidth,pageHeight:document.documentElement.scrollHeight,
      primary:bounds(kpis[0]),shooting:bounds(kpis[1]),trend:bounds(get('.player-chart')),log:bounds(get('.player-log')),
      tiles:document.querySelectorAll('.player-kpis > div').length,font:get('.player-center')&&getComputedStyle(get('.player-center')).fontFamily,
      fonts:document.fonts.size,targets}
  })
  assert.equal(metrics.tiles,32)
  assert.equal(metrics.documentWidth,width)
  assert.equal(requests.length,1)
  for(const [name,fullPage] of [['viewport',false],['full',true]]) {
    const flowNav=fullPage?await page.addStyleTag({content:'.gc-mobile-nav{position:static}'}):null
    try { await page.screenshot({path:out+'/'+width+'-'+name+'.png',fullPage,animations:'disabled'}) }
    finally { if(flowNav) await flowNav.evaluate(el=>el.remove()) }
  }
  records.push({width,height,requests,...metrics})
  await context.close()
 }
 await writeFile(base+'/evidence/baseline-measurements.json',JSON.stringify(records,null,2)+'\n')
} finally {
 await browser.close()
 await new Promise(resolve=>server.httpServer.close(resolve))
}
