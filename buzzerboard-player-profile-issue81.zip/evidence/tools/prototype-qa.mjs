import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const root=process.env.BB81_DELIVERY || fileURLToPath(new URL('../../',import.meta.url)).replace(/\/$/,'')
const resolver=process.env.BB81_PACKAGE
if(!resolver) throw new Error('Set BB81_PACKAGE to the baseline checkout package.json')
const {chromium}=createRequire(resolver)('playwright')
const fixture=JSON.parse(await readFile(root+'/assets/fixtures.json','utf8'))
const measured=[]
const checks=[]
const traffic=[]
const errors=[]
const sizes=[[1440,900],[768,1024],[375,812],[320,600]]
const browser=await chromium.launch()
const chrome=browser.version()
const required=[...fixture.raw.map(r=>r[0]),...fixture.advanced.map(r=>r.key),...fixture.per36.map(r=>r.key)]
const file=(name)=>pathToFileURL(path.join(root,name)).href

async function capture(page, name, fullPage=false) {
  const p=path.join(root,'shots',name+'.png')
  await mkdir(path.dirname(p),{recursive:true})
  await page.evaluate(()=>document.fonts.ready)
  const flowNav=fullPage?await page.addStyleTag({content:'.mobile-nav{position:static}'}):null
  try { await page.screenshot({path:p,fullPage,animations:'disabled'}) }
  finally { if(flowNav) await flowNav.evaluate(el=>el.remove()) }
}

async function setup(width,height) {
  const ctx=await browser.newContext({viewport:{width,height},locale:'ru-RU',timezoneId:'Asia/Nicosia'})
  await ctx.route(/^https?:/,(route)=>{traffic.push(route.request().url());return route.abort()})
  const page=await ctx.newPage()
  page.setDefaultTimeout(6500)
  page.on('pageerror',e=>errors.push(e.message))
  return {ctx,page}
}
const load=(page,variant,query='',hash='')=>page.goto(file(variant+'/index.html')+query+hash)
const btn=(page,name)=>page.getByRole('button',{name,exact:true})
const tab=(page,name)=>page.getByRole('tab',{name,exact:true})
const logRows=(page)=>page.locator('.log-table tbody tr')
const logo=(page)=>page.locator('.identity .team-link')
const coverage=async(page)=>new Set(await page.locator('[data-metric]').evaluateAll(el=>el.map(n=>n.dataset.metric)))
const exactCoverage=async(page)=>assert.deepEqual([...await coverage(page)].sort(),[...required].sort())

async function measure(page,variant,section,w,h) {
  const row=await page.evaluate(()=>{
    const round=x=>Math.round(x*10)/10
    const get=s=>document.querySelector(s)
    const bounds=el=>{if(!el)return null; const r=el.getBoundingClientRect();return {top:round(r.top+scrollY),bottom:round(r.bottom+scrollY),width:round(r.width),height:round(r.height)}}
    const nav=get('.mobile-nav')
    const fold=nav&&nav.getBoundingClientRect().height?nav.getBoundingClientRect().top:innerHeight
    const targets=Object.fromEntries(Object.entries({
      favorite:'[data-action=favorite]',back:'.back',spoiler:'[data-action=spoiler]',
      trend:'.metrics-tabs button',sort:'.log-table th button',game:'.log-table tbody a',tab:'.section-nav a,.section-nav button',source:'.source summary'
    }).map(([k,s])=>[k,bounds(get(s))]))
    const dimensions=['primary','shooting','trend','log','log-preview'].map(k=>[k,bounds(get('[data-measure="'+k+'"]'))])
    const firstGame=bounds(get('.log-table tbody tr,.b-brief .brief-row'))
    return {fold,documentWidth:document.documentElement.scrollWidth,pageHeight:document.documentElement.scrollHeight,
      ...Object.fromEntries(dimensions),firstGame,targets,
      font:getComputedStyle(get('main')).fontFamily,fonts:[...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family),
      metricCount:new Set([...document.querySelectorAll('[data-metric]')].map(n=>n.dataset.metric)).size,
      independentTiles:document.querySelectorAll('.independent-kpi').length}
  })
  assert.equal(row.documentWidth,w,variant+' '+section+' '+w+' overflow')
  assert.match(row.font,/Manrope/)
  assert(row.fonts.length>=2,'Manrope subsets should decode')
  for(const [name,rect] of Object.entries(row.targets)) if(rect)
    assert(rect.width>=44&&rect.height>=44,variant+' '+section+' '+w+' '+name+' target '+JSON.stringify(rect))
  if(section==='overview'){
    assert(row.primary.bottom<=row.fold)
    assert(row.shooting.bottom<=row.fold,variant+' '+w+' shooting bottom '+row.shooting.bottom+' fold '+row.fold)
  }
  measured.push({variant,section,width:w,height:h,...row})
}
async function assertNoOverflow(page,w){
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),w)
}
async function noLeak(page) {
  const markup=await page.locator('main').innerHTML()
  assert.equal(await page.locator('[data-metric], [data-chart] svg').count(),0)
  for(const leak of ['66 %','59,5','>59<','>67<','<title>2026-11-25','<title>2026-11-26'])assert(!markup.includes(leak),leak)
}
try{
 for(const variant of ['a','b']){
   for (const [w,h] of sizes) {
     const {ctx,page}=await setup(w,h)
     try {
       await load(page,variant)
       await page.getByRole('heading',{name:'Luka Dončić'}).waitFor()
       await page.evaluate(()=>document.fonts.ready)
       assert.equal(await logo(page).count(),1,'same team appears once')
       await measure(page,variant,'overview',w,h)
       if(variant==='a') await exactCoverage(page)
       await capture(page,variant+'/'+w+'-viewport')
       await capture(page,variant+'/'+w+'-full',true)
       if(w<=700){
         const unobscured=await page.evaluate(()=>{
           scrollTo(0,document.documentElement.scrollHeight)
           const footer=document.querySelector('.site-footer').getBoundingClientRect()
           const dock=document.querySelector('.mobile-nav').getBoundingClientRect()
           scrollTo(0,0)
           return footer.bottom<=dock.top
         })
         assert(unobscured,variant+' '+w+' bottom navigation covers footer')
       }
       if(variant==='b'){
         await tab(page,'Статистика').click()
         await exactCoverage(page)
         await page.evaluate(()=>scrollTo(0,0))
         await measure(page,variant,'stats',w,h)
         await capture(page,variant+'/'+w+'-stats-viewport')
         await capture(page,variant+'/'+w+'-stats-full',true)
         await tab(page,'Матчи').click()
         assert.equal(await logRows(page).count(),8)
         await page.evaluate(()=>scrollTo(0,0))
         await measure(page,variant,'log',w,h)
         await capture(page,variant+'/'+w+'-log-viewport')
         await capture(page,variant+'/'+w+'-log-full',true)
       }
     }finally{await ctx.close()}
   }
   const {ctx,page}=await setup(375,812)
   try{
     await load(page,variant,'?spoiler=0&q=Luka&sort=pts')
     await page.locator('[data-chart] svg').waitFor()
     assert.equal(await page.locator('[data-chart] circle').count(),7)
     assert.equal(await page.locator('[data-chart] .chart-line').count(),5,'bounds preserve a missing point')
     for(const [label,key] of [['Подборы','reb'],['Передачи','ast'],['Минуты','min'],['Очки','pts']]){
       await btn(page,label).press('Enter')
       assert.equal(await btn(page,label).getAttribute('aria-pressed'),'true')
       assert.equal(await page.locator('[data-chart] circle').count(),key==='pts'?7:8)
       assert.equal(await btn(page,label).evaluate(el=>el===document.activeElement),true)
     }
     await page.locator('.source summary').press('Enter')
     assert.equal(await page.locator('.source').getAttribute('open'),'')
     await page.getByText('Последний завершённый цикл',{exact:true}).waitFor()
     await page.locator('.source summary').press('Enter')
     if(variant==='b'){
       await tab(page,'Обзор').press('ArrowRight')
       assert.equal(await tab(page,'Статистика').getAttribute('aria-selected'),'true')
       assert.equal(await tab(page,'Статистика').evaluate(el=>el===document.activeElement),true)
     }
     await page.locator('.def-links summary').press('Enter')
     await page.getByText(/При нуле потерь/).waitFor()
     if(variant==='b') await tab(page,'Статистика').press('ArrowRight')
     assert.equal(await logRows(page).count(),8)
     const scroller=page.locator('.table-scroll')
     await scroller.focus()
     await page.keyboard.press('ArrowRight')
     await page.waitForFunction(()=>document.querySelector('.table-scroll').scrollLeft>0)
     assert(await scroller.evaluate(el=>el===document.activeElement))
     await scroller.evaluate(el=>el.scrollLeft=el.scrollWidth)
     await scroller.scrollIntoViewIfNeeded()
     await capture(page,variant+'/state-keyboard-table-375')
     for(const name of ['Очки','Подборы','Передачи','Минуты','Соперник','Дата']){
       const control=btn(page,'Сортировать: '+name)
       await control.press('Enter')
       const heading=page.locator('th[aria-sort]')
       let direction=await heading.getAttribute('aria-sort')
       assert.equal(await heading.count(),1)
       if(name==='Очки') assert.equal(await logRows(page).last().locator('[data-log-stat="pts"]').innerText(),'—')
       await control.press('Enter')
       assert.notEqual(await heading.getAttribute('aria-sort'),direction)
       if(name==='Очки') assert.equal(await logRows(page).last().locator('[data-log-stat="pts"]').innerText(),'—')
       assert(await control.evaluate(el=>el===document.activeElement))
     }
     const favorite=btn(page,'Избранное: Luka Dončić')
     await favorite.press('Enter')
     assert.equal(await favorite.getAttribute('aria-pressed'),'true')
     await page.reload()
     assert.equal(await favorite.getAttribute('aria-pressed'),'true')
     if(variant==='b'&&!(await logRows(page).count())) await tab(page,'Матчи').click()
     const link=page.locator('.date-link').first()
     assert((await link.getAttribute('data-app-route')).includes('date=2026-11'))
     await link.click()
     await page.getByRole('link',{name:'К профилю игрока',exact:true}).click()
     assert.equal(new URL(page.url()).searchParams.get('q'),'Luka')
     await page.getByRole('link',{name:'К списку игроков',exact:true}).click()
     await page.getByText('Поиск: Luka',{exact:true}).waitFor()
     await load(page,variant,'?from=favorites&spoiler=0')
     await page.getByRole('link',{name:'К избранному',exact:true}).click()
     assert.equal(new URL(page.url()).searchParams.get('view'),'favorites')
     const saved=page.getByRole('link',{name:'Luka Dončić',exact:true})
     await saved.waitFor()
     await saved.click()
     assert.equal(new URL(page.url()).searchParams.get('from'),'favorites')
     checks.push({variant,check:'chart, gaps, metric switches, source, formulas, keyboard tabs and table, six sort keys, null-last, favorites and linked routes',result:'PASS'})
   }finally{await ctx.close()}

   for (const mode of ['no-log','partial','no-stats','trade','unconfirmed','loading','error','protected']){
     const {ctx,page}=await setup(375,812)
     try{
       await load(page,variant,'?state='+mode+'&spoiler='+(mode==='protected'?'1':'0')+(mode==='loading'?'&hold=1':''))
       await assertNoOverflow(page,375)
       if(mode==='no-log'){
         assert.equal(await page.locator('[data-chart] svg').count(),0)
         if(variant==='b')await tab(page,'Матчи').click()
         await page.getByRole('heading',{name:'Журнал матчей пока недоступен',exact:true}).waitFor()
       }
       if(mode==='partial'){
         assert.equal(await page.locator('[data-metric="reb"]').first().locator('dd').innerText(),'—')
         if(variant==='b')await tab(page,'Статистика').click()
         assert.equal(await page.locator('tr[data-metric="stl"] td').innerText(),'0')
         assert.equal(await page.locator('tr[data-metric="astTo"] td').innerText(),'—')
         await exactCoverage(page)
       }
       if(mode==='no-stats'){
         assert.equal(await page.locator('[data-metric]').count(),0)
         await page.getByText('Подтверждённых средних за сезон пока нет.').waitFor()
       }
       if(mode==='trade'){
         assert.equal(await logo(page).count(),2)
         const routes=await logo(page).evaluateAll(nodes=>nodes.map(n=>n.dataset.appRoute))
         assert.deepEqual(routes,['/teams/DAL','/teams/LAL'])
         await logo(page).last().click()
         assert.equal(new URL(page.url()).searchParams.get('team'),'LAL')
         await page.getByRole('link',{name:'К профилю игрока',exact:true}).click()
       }
       if(mode==='unconfirmed'){
         assert.equal(await logo(page).count(),1)
         await page.getByText('Не подтверждена',{exact:true}).waitFor()
       }
       if(mode==='loading') await page.locator('[aria-busy="true"]').waitFor()
       if(mode==='error') await page.getByRole('alert').waitFor()
       if(mode==='protected'){
         await noLeak(page)
         if(variant==='b') await tab(page,'Статистика').click()
         await noLeak(page)
         await capture(page,variant+'/state-protected-375',true)
         if(variant==='b') await tab(page,'Матчи').click()
         assert.equal(await page.getByRole('button',{name:'Показать результат',exact:true}).count(),1)
         assert.equal(await page.locator('tr[data-log-index="8"] [data-log-stat]').count(),0)
         assert.equal(await page.locator('tr[data-log-index="9"] [data-log-stat]').count(),0)
         await capture(page,variant+'/state-protected-log-375',true)
         await btn(page,'Показать результат').click()
         assert.equal(await page.locator('tr[data-log-index="8"] [data-log-stat=pts]').innerText(),'59')
         assert.equal(await page.locator('tr[data-log-index="9"] [data-log-stat]').count(),0)
         assert.equal(await page.locator('[data-metric]').count(),0,'game reveal must not reveal the aggregate')
         assert.equal(await page.locator('[data-chart] svg').count(),0)
         await capture(page,variant+'/state-single-reveal-375',true)
         if(variant==='b') await tab(page,'Обзор').click()
         await btn(page,'Показать статистику').click()
         assert.equal(await page.locator('[data-metric="pts"]').first().locator('dd').innerText(),'39')
         await page.locator('[data-chart] svg').waitFor()
         const chartTitles=await page.locator('[data-chart] svg title').allTextContents()
         assert(chartTitles.some((text)=>text==='2026-11-25 · Очки: 59'))
         assert(!chartTitles.some((text)=>text.startsWith('2026-11-26')))
         await capture(page,variant+'/state-aggregate-reveal-375',true)
         await btn(page,'Без спойлеров').click()
         if(variant==='b') await tab(page,'Матчи').click()
         assert.equal(await page.locator('tr[data-log-index="9"] [data-log-stat=pts]').innerText(),'67')
         await page.reload()
         assert.equal(await btn(page,'Без спойлеров').getAttribute('aria-pressed'),'false')
       } else {
         await page.evaluate(()=>scrollTo(0,0))
         await capture(page,variant+'/state-'+mode+'-375',true)
         if(mode==='error'){
           await btn(page,'Повторить запрос').click()
           await page.locator('[aria-busy="true"]').waitFor()
           await page.getByRole('heading',{name:'Luka Dončić',exact:true}).waitFor()
         }
       }
       checks.push({variant,check:mode,result:'PASS'})
     }finally{await ctx.close()}
   }
 }
 assert.deepEqual(traffic,[],'no remote requests during offline prototype tests')
 assert.deepEqual(errors,[])
 await writeFile(root+'/evidence/prototype-measurements.json',JSON.stringify(measured,null,2)+'\n')
 await writeFile(root+'/evidence/interactions.json',JSON.stringify({chrome,checks,externalRequests:traffic,browserErrors:errors},null,2)+'\n')
 console.log('Prototype runs:',measured.length,'measured viewports and tabs;',checks.length,'functional groups; 0 network requests')
}finally{await browser.close()}
