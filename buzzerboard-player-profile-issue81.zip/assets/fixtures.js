window.PlayerPrototypeData = {
  "now": "2026-11-26T20:00:00Z",
  "snapshots": {
    "default": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-18T16:45:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": 7.2,
          "ast": 7.8,
          "fgm": 12,
          "fga": 24.7,
          "fg": 0.486,
          "threeM": 5.4,
          "threeA": 13.3,
          "three": 0.406,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 1.8,
          "blk": 0.7,
          "oreb": 0.3,
          "dreb": 6.8,
          "tov": 4.8,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-18T17:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          }
        ]
      }
    },
    "no-log": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-18T16:45:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": 7.2,
          "ast": 7.8,
          "fgm": 12,
          "fga": 24.7,
          "fg": 0.486,
          "threeM": 5.4,
          "threeA": 13.3,
          "three": 0.406,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 1.8,
          "blk": 0.7,
          "oreb": 0.3,
          "dreb": 6.8,
          "tov": 4.8,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": null,
        "games": []
      }
    },
    "partial": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-18T16:45:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": null,
          "ast": 7.8,
          "fgm": 12,
          "fga": null,
          "fg": null,
          "threeM": null,
          "threeA": null,
          "three": null,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 0,
          "blk": 0.7,
          "oreb": null,
          "dreb": 6.8,
          "tov": 0,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-18T17:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          }
        ]
      }
    },
    "no-stats": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": null,
        "stats": null
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-18T17:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          }
        ]
      }
    },
    "trade": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "DAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-18T16:45:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": 7.2,
          "ast": 7.8,
          "fgm": 12,
          "fga": 24.7,
          "fg": 0.486,
          "threeM": 5.4,
          "threeA": 13.3,
          "three": 0.406,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 1.8,
          "blk": 0.7,
          "oreb": 0.3,
          "dreb": 6.8,
          "tov": 4.8,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-18T17:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          }
        ]
      }
    },
    "unconfirmed": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-18T17:20:00Z",
      "isStale": true,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-18T16:45:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": 7.2,
          "ast": 7.8,
          "fgm": 12,
          "fga": 24.7,
          "fg": 0.486,
          "threeM": 5.4,
          "threeA": 13.3,
          "three": 0.406,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 1.8,
          "blk": 0.7,
          "oreb": 0.3,
          "dreb": 6.8,
          "tov": 4.8,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": null,
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-18T17:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          }
        ]
      }
    },
    "protected": {
      "source": "bbs",
      "seasonEndYear": 2027,
      "fetchedAt": "2026-11-26T16:00:00Z",
      "isStale": false,
      "coverage": {
        "providerRows": 534,
        "total": 520,
        "checked": 310,
        "averages": 266,
        "enriched": 74,
        "boxLinks": 183
      },
      "refreshStatus": {
        "phase": "averages",
        "total": 520,
        "checked": 310,
        "updated": 126,
        "retained": 140,
        "failed": 12,
        "cycleStartedAt": "2026-11-18T16:30:00Z",
        "lastCompletedAt": "2026-11-17T18:00:00Z",
        "nextCycleAt": 1795105800000
      },
      "player": {
        "id": "bbs:player:00000000-0000-4000-8000-000000008101",
        "name": "Luka Dončić",
        "team": "LAL",
        "position": "G",
        "number": "77",
        "height": null,
        "weight": null,
        "averageUpdatedAt": "2026-11-26T15:30:00Z",
        "stats": {
          "gp": 12,
          "min": 35.9,
          "pts": 39,
          "reb": 7.2,
          "ast": 7.8,
          "fgm": 12,
          "fga": 24.7,
          "fg": 0.486,
          "threeM": 5.4,
          "threeA": 13.3,
          "three": 0.406,
          "ftm": 9.6,
          "fta": 11.1,
          "ft": 0.865,
          "stl": 1.8,
          "blk": 0.7,
          "oreb": 0.3,
          "dreb": 6.8,
          "tov": 4.8,
          "pf": 2.8
        }
      },
      "detail": {
        "birthDate": null,
        "currentTeam": "LAL",
        "profileAt": "2026-11-18T12:00:00Z",
        "logAt": "2026-11-26T16:00:00Z",
        "games": [
          {
            "date": "2026-11-06",
            "opponent": "SAS",
            "gameId": "bbs:game:prototype-81-06",
            "pts": 28,
            "reb": 6,
            "ast": 10,
            "min": 34
          },
          {
            "date": "2026-11-08",
            "opponent": "POR",
            "gameId": "bbs:game:prototype-81-08",
            "pts": 44,
            "reb": 8,
            "ast": 7,
            "min": 38
          },
          {
            "date": "2026-11-09",
            "opponent": "MIN",
            "gameId": "bbs:game:prototype-81-09",
            "pts": 37,
            "reb": 7,
            "ast": 9,
            "min": 36
          },
          {
            "date": "2026-11-11",
            "opponent": "GSW",
            "gameId": null,
            "pts": null,
            "reb": 9,
            "ast": 6,
            "min": 35
          },
          {
            "date": "2026-11-13",
            "opponent": "DEN",
            "gameId": "bbs:game:prototype-81-13",
            "pts": 31,
            "reb": 4,
            "ast": 0,
            "min": 34
          },
          {
            "date": "2026-11-14",
            "opponent": "PHX",
            "gameId": "bbs:game:prototype-81-14",
            "pts": 47,
            "reb": 10,
            "ast": 11,
            "min": 38
          },
          {
            "date": "2026-11-16",
            "opponent": "CHI",
            "gameId": "bbs:game:prototype-81-16",
            "pts": 35,
            "reb": 7,
            "ast": 8,
            "min": 34
          },
          {
            "date": "2026-11-18",
            "opponent": "OKC",
            "gameId": "bbs:game:prototype-81-18",
            "pts": 42,
            "reb": 9,
            "ast": 6,
            "min": 37
          },
          {
            "date": "2026-11-25",
            "opponent": "BOS",
            "gameId": "bbs:game:prototype-81-25",
            "pts": 59,
            "reb": 13,
            "ast": 11,
            "min": 42
          },
          {
            "date": "2026-11-26",
            "opponent": "NYK",
            "gameId": null,
            "pts": 67,
            "reb": 12,
            "ast": 14,
            "min": 44
          }
        ]
      }
    }
  },
  "derived": {
    "default": {
      "ts": 0.6591400757166036,
      "efg": 0.5951417004048583,
      "astTo": 1.625,
      "gmSc": 29.99,
      "threeRate": 0.5384615384615385,
      "freeThrowRate": 0.4493927125506073,
      "twoPoint": 0.5789473684210527,
      "pts36": 39.108635097493035,
      "reb36": 7.220055710306407,
      "ast36": 7.821727019498608,
      "stl36": 1.8050139275766017,
      "blk36": 0.701949860724234
    },
    "no-log": {
      "ts": 0.6591400757166036,
      "efg": 0.5951417004048583,
      "astTo": 1.625,
      "gmSc": 29.99,
      "threeRate": 0.5384615384615385,
      "freeThrowRate": 0.4493927125506073,
      "twoPoint": 0.5789473684210527,
      "pts36": 39.108635097493035,
      "reb36": 7.220055710306407,
      "ast36": 7.821727019498608,
      "stl36": 1.8050139275766017,
      "blk36": 0.701949860724234
    },
    "partial": {
      "ts": null,
      "efg": null,
      "astTo": null,
      "gmSc": null,
      "threeRate": null,
      "freeThrowRate": null,
      "twoPoint": null,
      "pts36": 39.108635097493035,
      "reb36": null,
      "ast36": 7.821727019498608,
      "stl36": 0,
      "blk36": 0.701949860724234
    },
    "no-stats": {
      "ts": null,
      "efg": null,
      "astTo": null,
      "gmSc": null,
      "threeRate": null,
      "freeThrowRate": null,
      "twoPoint": null,
      "pts36": null,
      "reb36": null,
      "ast36": null,
      "stl36": null,
      "blk36": null
    },
    "trade": {
      "ts": 0.6591400757166036,
      "efg": 0.5951417004048583,
      "astTo": 1.625,
      "gmSc": 29.99,
      "threeRate": 0.5384615384615385,
      "freeThrowRate": 0.4493927125506073,
      "twoPoint": 0.5789473684210527,
      "pts36": 39.108635097493035,
      "reb36": 7.220055710306407,
      "ast36": 7.821727019498608,
      "stl36": 1.8050139275766017,
      "blk36": 0.701949860724234
    },
    "unconfirmed": {
      "ts": 0.6591400757166036,
      "efg": 0.5951417004048583,
      "astTo": 1.625,
      "gmSc": 29.99,
      "threeRate": 0.5384615384615385,
      "freeThrowRate": 0.4493927125506073,
      "twoPoint": 0.5789473684210527,
      "pts36": 39.108635097493035,
      "reb36": 7.220055710306407,
      "ast36": 7.821727019498608,
      "stl36": 1.8050139275766017,
      "blk36": 0.701949860724234
    },
    "protected": {
      "ts": 0.6591400757166036,
      "efg": 0.5951417004048583,
      "astTo": 1.625,
      "gmSc": 29.99,
      "threeRate": 0.5384615384615385,
      "freeThrowRate": 0.4493927125506073,
      "twoPoint": 0.5789473684210527,
      "pts36": 39.108635097493035,
      "reb36": 7.220055710306407,
      "ast36": 7.821727019498608,
      "stl36": 1.8050139275766017,
      "blk36": 0.701949860724234
    }
  },
  "raw": [
    [
      "gp",
      "GP",
      "Матчи",
      "basic"
    ],
    [
      "min",
      "MIN",
      "Минуты",
      "basic"
    ],
    [
      "pts",
      "PTS",
      "Очки",
      "basic"
    ],
    [
      "reb",
      "REB",
      "Подборы",
      "basic"
    ],
    [
      "ast",
      "AST",
      "Передачи",
      "basic"
    ],
    [
      "fgm",
      "FGM",
      "Попадания с игры",
      "shooting"
    ],
    [
      "fga",
      "FGA",
      "Попытки с игры",
      "shooting"
    ],
    [
      "fg",
      "FG%",
      "С игры, %",
      "shooting"
    ],
    [
      "threeM",
      "3PM",
      "Трёхочковые попадания",
      "shooting"
    ],
    [
      "threeA",
      "3PA",
      "Трёхочковые попытки",
      "shooting"
    ],
    [
      "three",
      "3P%",
      "Трёхочковые, %",
      "shooting"
    ],
    [
      "ftm",
      "FTM",
      "Штрафные попадания",
      "shooting"
    ],
    [
      "fta",
      "FTA",
      "Штрафные попытки",
      "shooting"
    ],
    [
      "ft",
      "FT%",
      "Штрафные, %",
      "shooting"
    ],
    [
      "stl",
      "STL",
      "Перехваты",
      "defense"
    ],
    [
      "blk",
      "BLK",
      "Блок-шоты",
      "defense"
    ],
    [
      "oreb",
      "OREB",
      "Подборы в атаке",
      "defense"
    ],
    [
      "dreb",
      "DREB",
      "Подборы в защите",
      "defense"
    ],
    [
      "tov",
      "TO",
      "Потери",
      "defense"
    ],
    [
      "pf",
      "PF",
      "Фолы",
      "defense"
    ]
  ],
  "advanced": [
    {
      "key": "ts",
      "short": "TS%",
      "label": "Истинная точность броска",
      "description": "PTS / (2 × (FGA + 0,44 × FTA)); 0,44 — оценка вклада штрафных в бросковые владения.",
      "format": "percent"
    },
    {
      "key": "efg",
      "short": "eFG%",
      "label": "Эффективность бросков с игры",
      "description": "(FGM + 0,5 × 3PM) / FGA; учитывает дополнительную ценность трёхочкового.",
      "format": "percent"
    },
    {
      "key": "astTo",
      "short": "AST/TO",
      "label": "Передачи к потерям",
      "description": "AST / TOV. При нуле потерь отношение не определено и показано как «—».",
      "format": "number"
    },
    {
      "key": "gmSc",
      "short": "GmSc/игру (оценка)",
      "label": "Game Score за игру (оценка)",
      "description": "Оценка Джона Холлинджера для одной игры; сезонное значение линейно рассчитано по средним BBS.",
      "format": "number"
    },
    {
      "key": "threeRate",
      "short": "3PAr",
      "label": "Доля трёхочковых попыток",
      "description": "3PA / FGA. Доля бросков с игры, пришедшихся на трёхочковые.",
      "format": "percent"
    },
    {
      "key": "freeThrowRate",
      "short": "FTr",
      "label": "Штрафные попытки к броскам с игры",
      "description": "FTA / FGA; показатель может быть выше 100%.",
      "format": "percent"
    },
    {
      "key": "twoPoint",
      "short": "2P%",
      "label": "Точность двухочковых",
      "description": "(FGM − 3PM) / (FGA − 3PA); доступна только при валидных данных бросков.",
      "format": "percent"
    }
  ],
  "per36": [
    {
      "key": "pts36",
      "short": "PTS/36",
      "label": "Очки за 36 минут",
      "source": "pts"
    },
    {
      "key": "reb36",
      "short": "REB/36",
      "label": "Подборы за 36 минут",
      "source": "reb"
    },
    {
      "key": "ast36",
      "short": "AST/36",
      "label": "Передачи за 36 минут",
      "source": "ast"
    },
    {
      "key": "stl36",
      "short": "STL/36",
      "label": "Перехваты за 36 минут",
      "source": "stl"
    },
    {
      "key": "blk36",
      "short": "BLK/36",
      "label": "Блок-шоты за 36 минут",
      "source": "blk"
    }
  ],
  "teams": {
    "LAL": "Los Angeles Lakers",
    "DAL": "Dallas Mavericks"
  }
};
