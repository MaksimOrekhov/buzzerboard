(() => {
  'use strict'
  const model = window.PlayerPrototypeData
  const glyphs = window.PlayerPrototypeIcons
  const app = document.querySelector('#app')
  const layout = document.documentElement.dataset.layout
  const params = new URLSearchParams(location.search)
  const variant = layout === 'context' ? (params.get('v') === 'b' ? 'b' : 'a') : layout
  const prefix = layout === 'context' ? './' : '../'
  const activeState = params.get('state') || 'default'
  const knownViews = ['overview','stats','log']
  const dateKey = (instant) =>
    new Intl.DateTimeFormat('en-CA', { timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit' }).format(instant)
  const today = dateKey(new Date(model.now))
  const yesterday = dateKey(new Date(Date.parse(model.now) - 86400000))
  const scope = 'player:' + model.snapshots.default.player.id
  const prefKey = 'buzzerboard:profile-study:spoiler'
  const favoriteKey = 'buzzerboard:profile-study:favorite'
  const read = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback }
  }
  const write = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* runtime state remains usable */ } }
  const pref = read(prefKey, {enabled:false,day:today,aggregates:[],games:[]})
  const settings = {
    enabled: params.has('spoiler') ? params.get('spoiler') === '1' : Boolean(pref.enabled),
    day:today, aggregates:pref.day===today && Array.isArray(pref.aggregates)?pref.aggregates:[],
    games:pref.day===today && Array.isArray(pref.games)?pref.games:[],
  }
  let favorite = read(favoriteKey,false) === true
  let state = activeState
  let metric = 'pts'
  let sort = 'date'
  let ascending = false
  let observer
  const logMetrics = [
    {key:'pts',label:'Очки',short:'PTS'}, {key:'reb',label:'Подборы',short:'REB'},
    {key:'ast',label:'Передачи',short:'AST'}, {key:'min',label:'Минуты',short:'MIN'},
  ]
  const raw = Object.fromEntries(model.raw.map(([key,code,label,group])=>[key,{key,code,label,group}]))
  const advanced = Object.fromEntries(model.advanced.map(({key,short,label,description,format})=>[key,{key,code:key==='gmSc'?'GmSc':short,label,description,format}]))
  const per36 = Object.fromEntries(model.per36.map(({key,short,label})=>[key,{key,code:short,label}]))
  const format = new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1})
  const percent = new Intl.NumberFormat('ru-RU',{style:'percent',maximumFractionDigits:1})
  const stamp = new Intl.DateTimeFormat('ru-RU',{timeZone:'Asia/Nicosia',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})
  const value = (input, isPercent=false) => Number.isFinite(input)?(isPercent?percent:format).format(input):'—'
  const time = (input) => input ? stamp.format(new Date(input)) : '—'
  const isPercent = (key) => ['fg','three','ft'].includes(key) || advanced[key]?.format==='percent'
  const numeric = (key, amount) => value(amount,isPercent(key))
  const esc = (str) => String(str??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')
  const icon = (name) => '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+(glyphs[name]||glyphs.basketball)+'</svg>'
  const nav = [
    ['home','Обзор','Обзор','home'], ['games','Game Center','Матчи','basketball'], ['standings','Таблица','Таблица','trophy'],
    ['teams','Команды','Команды','users'], ['players','Игроки','Игроки','search'],
    ['news','Новости','Новости','news'], ['favorites','Избранное','Избр.','star'],
  ]
  const target = params.get('view') || 'players'
  const backType = params.get('from') === 'favorites' ? 'favorites' : 'players'
  const context = (view, fields={}) => prefix+'context.html?'+new URLSearchParams({
    v:variant,view,state,spoiler:settings.enabled?'1':'0',...fields,
  })
  const profileLink = (fields={}) => prefix+variant+'/index.html?'+new URLSearchParams({
    state,spoiler:settings.enabled?'1':'0',...fields,
  })
  const persistentScope = () => write(prefKey,settings)
  function view() {
    const selected = location.hash.slice(1)
    return knownViews.includes(selected) ? selected : 'overview'
  }
  function brand() {
    return '<a class="brand" href="'+esc(context('home'))+'"><span class="brand-mark">'+icon('basketball')+'</span><span class="brand-text">buzzerboard<span class="brand-dot">.</span></span></a>'
  }
  function nave(mobile) {
    return (mobile?nav:[...nav,['arenas','Арены','Арены','pin'],['cities','Города','Города','globe']])
      .map(([key,label,short,symbol])=>'<a class="nav-link" '+(key===(layout==='context'?target:'players')?'aria-current="page" ':'')+'href="'+esc(context(key))+'" aria-label="'+esc(label)+'">'+icon(symbol)+'<span>'+esc(mobile?short:label)+'</span></a>').join('')
  }
  function shell(content) {
    return '<a class="skip button" href="#main">К содержимому</a><aside class="app-rail">'+brand()+
      '<div class="league"><span class="league-mark">NBA</span><span class="league-copy">Национальная<br>баскетбольная ассоциация</span></div><nav class="nav-list" aria-label="Основная навигация">'+nave(false)+'</nav><div class="rail-end">BuzzerBoard · NBA</div></aside>'+
      '<div class="shell"><header class="topbar">'+brand()+'<div class="crumb">'+icon('basketball')+'<span>Баскетбол</span><span>/</span><strong>NBA</strong></div>'+
      '<div class="topbar-actions"><button class="button" type="button" data-action="spoiler" data-focus="spoiler" aria-pressed="'+settings.enabled+'">'+icon(settings.enabled?'eye-off':'eye')+'Без спойлеров</button>'+
      '<a class="button icon-button context-fav" aria-label="Открыть избранное" href="'+esc(context('favorites'))+'">'+icon('star')+'</a></div></header>'+
      '<main id="main" class="content" tabindex="-1">'+content+'</main></div><nav class="mobile-nav" aria-label="Мобильная навигация">'+nave(true)+'</nav>'
  }
  function team(code) {
    if (!code || !model.teams[code]) return '<span class="unconfirmed">Не подтверждена</span>'
    return '<a class="team-link" data-app-route="/teams/'+esc(code)+'" href="'+esc(context('teams',{team:code,from:backType}))+'"><span class="team-code">'+esc(code)+'</span>'+esc(model.teams[code])+icon('arrow-up-right')+'</a>'
  }
  function ageAt(birth, date) {
    if (!birth || !date || birth>=date) return null
    const age=Number(date.slice(0,4))-Number(birth.slice(0,4))-(date.slice(5,10)<birth.slice(5)?1:0)
    return age>0&&age<80?age:null
  }
  function identity(snapshot) {
    const {player,detail}=snapshot
    const current=detail?.currentTeam
    const initial=player.name.trim().split(/\s+/).slice(0,2).map((item)=>item.charAt(0)).join('')
    const age=ageAt(detail?.birthDate,detail?.profileAt?.slice(0,10))
    const facts=[player.position,player.number?'№ '+player.number:null, age?age+' лет':null,player.height,player.weight].filter(Boolean)
    const teamLine=player.team && player.team===current
      ? team(current)
      : [player.team?'<span class="team-state"><small>Каталог сезона</small>'+team(player.team)+'</span>':'',
        '<span class="team-state"><small>Текущая команда</small>'+team(current)+'</span>'].join('')
    return '<header class="identity '+variant+'-identity"><div class="identity-core"><div class="initials" aria-hidden="true">'+esc(initial)+'</div><div class="identity-name">'+
      '<div class="eyebrow-line"><span class="eyebrow">Игрок · 2026/27</span><span class="fixture-label" title="Синтетический снимок">Демо-данные</span></div>'+
      '<h1>'+esc(player.name)+'</h1><div class="identity-facts"><div class="team-list">'+teamLine+'</div>'+(facts.length?'<span>'+esc(facts.join(' · '))+'</span>':'')+'</div></div></div>'+
      '<div class="identity-action"><button type="button" class="button star" data-action="favorite" data-focus="favorite" aria-label="Избранное: '+esc(player.name)+'" aria-pressed="'+favorite+'">'+icon('star')+
      '<span class="favorite-copy">'+(favorite?'В избранном':'В избранное')+'</span></button></div>'+source(snapshot)+'</header>'
  }
  function source(snapshot) {
    const {player,detail,refreshStatus:refresh,coverage}=snapshot
    const phase={directory:'Каталог',averages:'Средние',publish:'Публикация',retry:'Повтор',gameRefs:'Связи матчей',enrich:'Дополнение',idle:'Ожидание'}
    const fields=[
      ['Снимок BBS',time(snapshot.fetchedAt)],['Средние игрока',time(player.averageUpdatedAt)],
      ['Профиль',time(detail?.profileAt)],['Журнал',time(detail?.logAt)],
      ['Каталог',coverage.total+' игроков'],['Средние опубликованы',coverage.averages+' игроков'],
    ]
    if(refresh) fields.push(['Цикл',phase[refresh.phase]+' · '+refresh.checked+'/'+refresh.total+' проверено'],
      ['Последний завершённый цикл',time(refresh.lastCompletedAt)])
    return '<details class="source '+(snapshot.isStale?'stale':'')+'" data-source><summary data-focus="source"><span class="source-dot"></span>'+
      '<strong>BBS</strong><span class="source-status">'+(snapshot.isStale?'Снимок устарел':'Снимок за дату')+'</span><time datetime="'+esc(snapshot.fetchedAt)+'">'+esc(time(snapshot.fetchedAt))+'</time>'+
      '<span class="sr">Источники и покрытие</span>'+icon('down')+'</summary><dl class="source-details">'+fields.map(([k,v])=>'<div><dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl></details>'
  }
  const shotGroups=[
    ['fg','С игры','fgm','fga'], ['three','Трёхочковые','threeM','threeA'], ['ft','Штрафные','ftm','fta']
  ]
  function primary(stats) {
    return '<section id="overview" class="panel primary" data-measure="primary" aria-labelledby="primary-title"><h2 id="primary-title">Средние за матч</h2>'+
      '<dl class="primary-grid">'+['pts','reb','ast'].map((key)=>'<div class="primary-cell" data-metric="'+key+'"><dt aria-label="'+esc(raw[key].label)+'">'+raw[key].code+' <span>'+esc(raw[key].label)+'</span></dt><dd>'+numeric(key,stats[key])+'</dd></div>').join('')+'</dl>'+
      '<div class="volume"><span data-metric="gp"><strong>'+numeric('gp',stats.gp)+'</strong>матчей · GP</span><span data-metric="min"><strong>'+numeric('min',stats.min)+'</strong>мин за матч</span></div></section>'
  }
  function shooting(stats, style) {
    return '<section class="panel shooting-panel '+style+'-shooting" data-measure="shooting" aria-labelledby="shooting-title"><header class="panel-head"><h2 id="shooting-title">'+
      (style==='b'?'Бросковый профиль':'Броски')+'</h2><span class="meta">Поп. / попытки</span></header><div class="shooting-list">'+
      shotGroups.map(([pct,label,made,attempt])=>{
        const fill=Number.isFinite(stats[pct])?stats[pct]*100:0
        const css='style="--pct:'+fill+'%"'
        const pctValue='<span data-metric="'+pct+'" class="shooting-pct" aria-label="'+esc(raw[pct].code+' '+numeric(pct,stats[pct]))+'">'+numeric(pct,stats[pct])+'</span>'
        const name='<span class="shooting-name"><small>'+raw[pct].code+'</small>'+label+'</span>'
        const attempts='<span class="made"><b data-metric="'+made+'" title="'+esc(raw[made].label)+'">'+numeric(made,stats[made])+'</b> / <span data-metric="'+attempt+'" title="'+esc(raw[attempt].label)+'">'+numeric(attempt,stats[attempt])+'</span></span>'
        return '<div class="shooting-row">'+(style==='a' ? name+'<span class="track" aria-hidden="true" '+css+'><i></i></span>'+attempts+pctValue
          : '<span class="ring" '+css+'>'+pctValue+'</span>'+name+attempts)+'</div>'
      }).join('')+'</div></section>'
  }
  function metricTable(title, entries, values) {
    return '<section class="stat-group"><h3>'+title+'</h3><table class="stat-table" aria-label="'+esc(title)+'"><tbody>'+
      entries.map(({key,code,label})=>'<tr data-metric="'+key+'"><th scope="row"><span class="stat-code">'+esc(code)+'</span>'+esc(label)+'</th><td>'+numeric(key,values[key])+'</td></tr>').join('')+
      '</tbody></table></section>'
  }
  function statsBoard(stats, style) {
    const data=model.derived[state] || model.derived.default
    const groups = [['Основное',['gp','min','pts','reb','ast']],['Броски',shotGroups.flatMap(([p,,m,a])=>[m,a,p])],['Защита и потери',['stl','blk','oreb','dreb','tov','pf']]]
    return '<section id="stats" class="panel stats-board '+(style==='a'?'a-board':'stats-b')+'"><h2>Статистика сезона</h2><p class="meta">Средние за игру · GP — количество матчей</p><div class="stats-grid">'+
      groups.map(([title,keys])=>metricTable(title,keys.map(k=>raw[k]),stats)).join('')+'</div><div class="stats-grid two">'+
      metricTable('Эффективность',Object.values(advanced),data)+metricTable('За 36 минут',Object.values(per36),data)+'</div>'+
      '<p class="note">Расчёт по средним BBS. Отношения приблизительны из-за округления. GmSc/игру — линейная оценка, не PER и не официальный рейтинг. Показатели за 36 минут — нормировка игрового времени, не прогноз.</p>'+
      '<details class="def-links"><summary data-focus="definitions">Формулы и определения</summary><dl>'+
      Object.values(advanced).map((entry)=>'<div><dt>'+esc(entry.code+' · '+entry.label)+'</dt><dd class="stat-def">'+esc(entry.description)+'</dd></div>').join('')+
      '<div><dt>За 36 минут</dt><dd class="stat-def">Среднее × 36 / средние минуты. При отсутствии входного показателя или игрового времени выводится тире.</dd></div></dl></details></section>'
  }
  const revealKey = (game) => game.gameId ? JSON.stringify([game.gameId,game.date]) : null
  function hiddenGame(game) {
    return settings.enabled && [yesterday,today].includes(game.date) && !settings.games.includes(revealKey(game))
  }
  function hiddenAggregate(snapshot) {
    const coverage=Date.parse(snapshot.player.averageUpdatedAt)
    const older=Number.isFinite(coverage)&&dateKey(new Date(coverage))<yesterday
    return settings.enabled&&!older&&!settings.aggregates.includes(scope)
  }
  function protection() {
    return '<section id="overview" class="panel data-state" data-protected><span class="eyebrow">Без спойлеров</span><h2 id="stats">Сезонная статистика скрыта</h2><p>Открытие средних и тренда не раскрывает отдельные матчи.</p><button class="button primary-action" data-action="aggregate" data-focus="gate">'+icon('eye')+'Показать статистику</button></section>'
  }
  function chartPanel(games, protectedStats) {
    if (!games.length) return ''
    if (protectedStats) return '<section class="panel data-state chart-panel"><h2>Тренд скрыт</h2><p>График появится после открытия статистики. Результаты матчей раскрываются отдельно.</p></section>'
    const eligible=games.filter((game)=>!hiddenGame(game))
    return '<section class="panel chart-panel" data-measure="trend"><div class="panel-head"><div><h2>'+(variant==='b'?'Форма по матчам':'Тренд')+'</h2><p class="meta">'+eligible.length+' из '+games.length+' матчей журнала · пропуски не нули</p></div>'+icon('chart')+'</div>'+
      '<div class="metrics-tabs" role="group" aria-label="Показатель графика">'+logMetrics.map(({key,label})=>'<button type="button" aria-pressed="'+(metric===key)+'" data-action="metric" data-value="'+key+'" data-focus="chart-'+key+'">'+label+'</button>').join('')+'</div>'+
      '<div data-chart class="chart"></div></section>'
  }
  function drawChart(node, games) {
    if (!node) return
    const filtered=games.filter(g=>!hiddenGame(g)).sort((a,b)=>a.date.localeCompare(b.date))
    const valid=filtered.filter(g=>Number.isFinite(g[metric]))
    if(!valid.length) { node.innerHTML='<p class="note">Для графика нет значений.</p>';return }
    const width=Math.max(250,Math.floor(node.clientWidth))
    const h=variant==='b'&&width>520?202:155
    const y0=h-32, y1=13, x0=35, x1=width-14
    const max=Math.max(5,Math.ceil(Math.max(0,...valid.map(g=>g[metric]))/5)*5)
    const gx=i=>filtered.length===1?(x0+x1)/2:x0+(x1-x0)*i/(filtered.length-1)
    const gy=v=>y0-(y0-y1)*v/max
    const selected=logMetrics.find(item=>item.key===metric)
    const ticks=[0,max/2,max].map(v=>'<line class="axis" x1="'+x0+'" x2="'+x1+'" y1="'+gy(v)+'" y2="'+gy(v)+'"/><text x="'+(x0-6)+'" y="'+(gy(v)+4)+'" text-anchor="end">'+value(v)+'</text>').join('')
    const edges=filtered.slice(1).map((g,i)=>{
      const p=filtered[i]
      return Number.isFinite(p[metric])&&Number.isFinite(g[metric])
        ? '<line class="chart-line" x1="'+gx(i)+'" y1="'+gy(p[metric])+'" x2="'+gx(i+1)+'" y2="'+gy(g[metric])+'"/>' : ''
    }).join('')
    const dots=filtered.map((g,i)=>Number.isFinite(g[metric])?'<circle cx="'+gx(i)+'" cy="'+gy(g[metric])+'" r="4.3"><title>'+g.date+' · '+selected.label+': '+value(g[metric])+'</title></circle>':'').join('')
    const dayLabel=(day)=>day.slice(8,10)+'.'+day.slice(5,7)
    const axisLabels=filtered.length===1?'<text x="'+gx(0)+'" y="'+(h-9)+'" text-anchor="middle">'+dayLabel(filtered[0].date)+'</text>':
      [0,Math.round((filtered.length-1)/2),filtered.length-1].filter((v,i,a)=>a.indexOf(v)===i).map((i)=>'<text x="'+gx(i)+'" y="'+(h-9)+'" text-anchor="'+(i===0?'start':i===filtered.length-1?'end':'middle')+'">'+dayLabel(filtered[i].date)+'</text>').join('')
    node.innerHTML='<figure><svg viewBox="0 0 '+width+' '+h+'" role="img" aria-label="'+esc(selected.label)+' по доступным матчам">'+ticks+edges+dots+axisLabels+'</svg>'+
      '<figcaption>'+selected.label+' за матч · '+valid.length+' значений</figcaption></figure>'
  }
  function gameLink(game, text) {
    const date='<time datetime="'+game.date+'" title="'+game.date+'">'+esc(text)+'</time>'
    return game.gameId ? '<a class="date-link" aria-label="Открыть матч '+game.date+'" data-app-route="/games/'+encodeURIComponent(game.gameId)+'?date='+game.date+
      '&amp;from='+encodeURIComponent('/players/'+encodeURIComponent(model.snapshots.default.player.id))+
      '" href="'+esc(context('games',{game:game.gameId,date:game.date,from:backType,tab:view(),q:params.get('q')||'',sort:params.get('sort')||'',section:variant==='a'?'log':''}))+'">'+date+'</a>':date
  }
  function sortRows(games) {
    const sign=ascending?1:-1
    return [...games].sort((a,b)=>{
      if(sort==='date')return sign*a.date.localeCompare(b.date)
      if(sort==='opponent')return a.opponent===null?(b.opponent===null?b.date.localeCompare(a.date):1):b.opponent===null?-1:sign*a.opponent.localeCompare(b.opponent,'en')||b.date.localeCompare(a.date)
      const left=hiddenGame(a)?null:a[sort]
      const right=hiddenGame(b)?null:b[sort]
      if(left===null)return right===null?b.date.localeCompare(a.date):1
      if(right===null)return -1
      return sign*(left-right)||b.date.localeCompare(a.date)
    })
  }
  function logPanel(games) {
    if(!games.length)return '<section id="log" class="panel data-state"><h2>Журнал матчей пока недоступен</h2><p>Средние за сезон доступны в разделе статистики.</p></section>'
    const columns=[{key:'date',short:'Дата',label:'Дата'},{key:'opponent',short:'Соперник',label:'Соперник'},...logMetrics]
    return '<section id="log" class="panel log-panel" data-measure="log"><div class="panel-head"><div><h2>Журнал матчей</h2><p class="meta">BBS · '+games.length+' доступных встреч · NBA ET</p></div>'+icon('list')+'</div>'+
      '<div class="table-scroll" role="region" tabindex="0" aria-label="Журнал матчей игрока"><table class="log-table"><thead><tr>'+columns.map(({key,short,label})=>{
        const dir=sort===key?(ascending?'ascending':'descending'):null
        return '<th scope="col" '+(dir?'aria-sort="'+dir+'" ':'')+'class="'+(key==='date'?'date-cell':key==='opponent'?'date-cell':'')+'"><button type="button" data-action="sort" data-value="'+key+'" data-focus="sort-'+key+'" aria-label="Сортировать: '+label+'">'+short+(dir?icon(ascending?'up':'down'):'')+'</button></th>'
      }).join('')+'</tr></thead><tbody>'+sortRows(games).map((g)=>{
        const hidden=hiddenGame(g)
        const i=games.indexOf(g)
        return '<tr data-log-index="'+i+'"'+(hidden?' class="protected-row"':'')+'><th scope="row" class="date-cell">'+gameLink(g,g.date.slice(8,10)+'.'+g.date.slice(5,7))+'</th>'+
          '<td class="opp">'+esc(g.opponent??'—')+'</td>'+
          (hidden?'<td colspan="4"><span class="sr">Результат скрыт</span>'+(g.gameId?'<button class="text-button" type="button" data-action="game" data-value="'+i+'" data-focus="game-'+i+'">Показать результат</button>':'<span class="meta">Результат скрыт</span>')+'</td>':
          logMetrics.map(({key})=>'<td data-log-stat="'+key+'"'+(key==='pts'?' class="pts-column"':'')+'>'+value(g[key])+'</td>').join(''))+'</tr>'
      }).join('')+'</tbody></table></div></section>'
  }
  function recent(games) {
    const newest=[...games].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,2)
    return '<section class="panel recent-panel" data-measure="log-preview"><h2>Последние матчи</h2><div class="b-brief">'+
      (newest.length?newest.map(g=>'<div class="brief-row"><span>'+g.date.slice(8,10)+'.'+g.date.slice(5,7)+' · '+esc(g.opponent??'—')+'</span><strong>'+
        (hiddenGame(g)?'Результат скрыт':value(g.pts)+' очк.')+'</strong></div>').join(''):'<p class="meta">Журнал пока недоступен.</p>')+
      '</div>'+(games.length?'<button class="text-button" data-action="tab" data-value="log" data-focus="recent-link">Открыть журнал '+icon('arrow')+'</button>':'')+'</section>'
  }
  function sectionNav() {
    if(variant==='a')return '<nav class="section-nav" aria-label="Разделы профиля"><a href="#overview">Обзор</a><a href="#stats">Статистика</a><a href="#log">Матчи</a></nav>'
    return '<div class="section-nav b-tabs" role="tablist" aria-label="Разделы профиля">'+[['overview','Обзор'],['stats','Статистика'],['log','Матчи']].map(([key,label])=>
      '<button id="tab-'+key+'" role="tab" aria-selected="'+(view()===key)+'" aria-controls="player-view" tabindex="'+(view()===key?0:-1)+'" data-action="tab" data-value="'+key+'" data-focus="tab-'+key+'">'+label+'</button>').join('')+'</div>'
  }
  function errorState() {
    const pending=state==='loading'
    if(pending)return '<section class="panel data-state skeleton" role="status" aria-busy="true"><h2>Загружаем профиль</h2><span></span><span></span><span></span></section>'
    return '<section class="panel data-state" role="alert"><h2>Профиль недоступен</h2><p>Не удалось загрузить снимок игрока.</p><button class="button" type="button" data-action="retry" data-focus="retry">'+icon('refresh')+'Повторить запрос</button></section>'
  }
  function noStats() {
    return '<section id="overview" class="panel data-state" data-measure="primary"><h2>Средние за сезон</h2><p id="stats">Подтверждённых средних за сезон пока нет.</p></section>'
  }
  function footer() {
    return '<footer class="site-footer"><span>BuzzerBoard · Прототип профиля</span><a href="'+prefix+'index.html">Сценарии</a></footer>'
  }
  function profile() {
    const back='<a class="back" data-focus="back" data-app-route="/'+backType+'" href="'+esc(context(backType,{q:params.get('q')||'',sort:params.get('sort')||''}))+'">'+icon('chevron-left')+(backType==='favorites'?'К избранному':'К списку игроков')+'</a>'
    if(state==='error'||state==='loading') return back+errorState()+footer()
    const snapshot=model.snapshots[state]||model.snapshots.default
    const stats=snapshot.player.stats, games=snapshot.detail?.games??[]
    const protectedStats=hiddenAggregate(snapshot)
    const hero=identity(snapshot)
    const missing=protectedStats?protection():noStats()
    const front=stats&&!protectedStats
    let content
    if(variant==='a') {
      content=(front?'<div class="a-summary">'+primary(stats)+shooting(stats,'a')+'</div>':missing)+
        '<div class="a-analysis">'+chartPanel(games,protectedStats)+logPanel(games)+'</div>'+
        (front?statsBoard(stats,'a'):'')
    } else {
      if(view()==='stats')content=front?'<div class="b-stat-view">'+statsBoard(stats,'b')+'</div>':missing
      else if(view()==='log')content=logPanel(games)
      else content='<div class="b-grid"><div class="b-main">'+(front?primary(stats):'<div class="primary">'+missing+'</div>')+chartPanel(games,protectedStats)+'</div><div class="b-side">'+(front?shooting(stats,'b'):'')+recent(games)+'</div></div>'
      content='<div role="tabpanel" id="player-view" aria-labelledby="tab-'+view()+'">'+content+'</div>'
    }
    return back+hero+sectionNav()+content+footer()
  }
  function contextView() {
    const snapshot=model.snapshots[state]||model.snapshots.default
    const game=snapshot.detail?.games.find((g)=>g.gameId===params.get('game')&&g.date===params.get('date'))
    const back=profileLink({from:params.get('from')==='favorites'?'favorites':'players',q:params.get('q')||'',sort:params.get('sort')||''})+(params.get('tab')&&variant==='b'?'#'+viewFor(params.get('tab')):params.get('section')==='log'?'#log':'')
    const title= target==='players'?'Каталог игроков':target==='favorites'?'Избранное':target==='teams'?(model.teams[params.get('team')]||'Команды'):target==='games'&&game?'Матч · '+game.date:(nav.find(n=>n[0]===target)?.[1]||'NBA')
    const rosterLink='<a class="team-link" href="'+esc(profileLink({from: target==='favorites'?'favorites':'players',q:params.get('q')||'',sort:params.get('sort')||''}))+'">'+esc(snapshot.player.name)+icon('arrow')+'</a>'
    const content= target==='players'||target==='favorites'
      ? (target==='favorites'&&!favorite?'<p class="note">В избранном пока нет игрока.</p>':rosterLink)+
        (params.get('q')?'<p class="note">Поиск: '+esc(params.get('q'))+'</p>':'')+
        (params.get('sort')?'<p class="note">Сортировка: '+esc(params.get('sort'))+'</p>':'')
      : game?'<p class="note">NBA ET · '+esc(game.date)+' · соперник '+esc(game.opponent??'—')+'</p>'+
        (hiddenGame(game)?'<p class="notice">Результат скрыт</p>':'<dl class="source-details">'+logMetrics.map(({key,label})=>'<div><dt>'+label+'</dt><dd>'+value(game[key])+'</dd></div>').join('')+'</dl>'):''
    return '<section class="panel context-panel"><p class="eyebrow">Офлайн-прототип</p><h1>'+esc(title)+'</h1><p class="meta">'+
      (game?'Доступная запись журнала игрока.':'Контекст перехода из профиля.')+'</p>'+content+
      '<div class="context-links"><a class="button" href="'+esc(back)+'">'+icon('chevron-left')+'К профилю игрока</a><a class="button" href="./index.html">Сценарии</a></div></section>'
  }
  const viewFor = (key) => knownViews.includes(key) ? key : 'overview'
  function render(focus) {
    const top=scrollY
    const opened=app.querySelector('[data-source]')?.open
    const previousScroll=app.querySelector('.table-scroll')
    const internalPosition=previousScroll&&[previousScroll.scrollLeft,previousScroll.scrollTop]
    observer?.disconnect()
    app.innerHTML=shell(layout==='context'?contextView():profile())
    if(opened && app.querySelector('[data-source]'))app.querySelector('[data-source]').open=true
    if(internalPosition) app.querySelector('.table-scroll')?.scrollTo(...internalPosition)
    const node=app.querySelector('[data-chart]')
    if(node) {
      const games=(model.snapshots[state]||model.snapshots.default).detail?.games??[]
      drawChart(node, games)
      observer=new ResizeObserver(()=>drawChart(node,games))
      observer.observe(node)
    }
    if(focus) {
      const target=[...app.querySelectorAll('[data-focus]')].find(x=>x.dataset.focus===focus)||
        (focus.startsWith('game-')?app.querySelector('[data-log-index="'+focus.slice(5)+'"] a'):null)
      ;(target||app.querySelector('#main'))?.focus({preventScroll:true})
      scrollTo(0,top)
    }
  }
  function chooseTab(key) {
    const target = viewFor(key)
    if(view()!==target) history.pushState(null,'','#'+target)
    render('tab-'+target)
    app.querySelector('.b-tabs')?.scrollIntoView({block:'nearest'})
  }
  app.addEventListener('click',(event)=>{
    const control=event.target.closest('[data-action]')
    if(!control)return
    const {action,value:choice,focus}=control.dataset
    if(action==='tab') return chooseTab(choice)
    if(action==='favorite') { favorite=!favorite; write(favoriteKey,favorite) }
    if(action==='spoiler') {
      settings.enabled=!settings.enabled
      settings.aggregates=[]
      settings.games=[]
      persistentScope()
      if(params.has('spoiler')) {
        const url=new URL(location.href)
        url.searchParams.set('spoiler',settings.enabled?'1':'0')
        history.replaceState(null,'',url.href)
      }
    }
    if(action==='aggregate') { settings.aggregates=[...settings.aggregates,scope];persistentScope() }
    if(action==='game') {
      const game=(model.snapshots[state]||model.snapshots.default).detail?.games[Number(choice)]
      const key=game&&revealKey(game)
      if(game&&key&&hiddenGame(game)) { settings.games=[...settings.games,key];persistentScope() }
    }
    if(action==='sort') { ascending = sort===choice ? !ascending : choice==='opponent'; sort=choice }
    if(action==='metric') metric=choice
    if(action==='retry') {
      state='loading'
      setTimeout(()=>{state='default';render('back')},550)
    }
    render(focus)
  })
  app.addEventListener('keydown',(event)=>{
    if(!event.target.matches('[role="tab"]')||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return
    event.preventDefault()
    const index=knownViews.indexOf(view())
    const next=event.key==='Home'?0:event.key==='End'?2:(index+(event.key==='ArrowRight'?1:2))%3
    chooseTab(knownViews[next])
  })
  if(layout==='b')window.addEventListener('popstate',()=>render())
  render()
  if(layout!=='context'&&variant==='a'&&location.hash)requestAnimationFrame(()=>document.getElementById(location.hash.slice(1))?.scrollIntoView())
  if(layout!=='context'&&state==='loading'&&!params.has('hold'))setTimeout(()=>{state='default';render()},1500)
})()
