# BuzzerBoard · повторный QA #62

Откройте `index.html` для просмотра PNG и сравнений без сети или `REPORT.md` для отчёта. Сопоставимые записи находятся в `data/comparison.csv` и `data/comparison.json`, полные результаты двух прогонов в `data/baseline-probe-results.json` и `data/current-probe-results.json`.

## Воспроизведение на фикстурах

В чистом checkout BuzzerBoard на `e0f2b7bf5ac83ae39478081f8c6385d824278f30` использовать Node.js 22 и pnpm из package.json. В командах ниже `/path/to/qa62-retest` — каталог распакованного архива.

```sh
pnpm install --frozen-lockfile
pnpm exec playwright install chromium
pnpm build
BB_QA_REPO="$PWD" BB_QA_OUT="/tmp/buzzerboard-qa62-retake" node /path/to/qa62-retest/tools/qa-probes.mjs
pnpm run visual:pro171 --compact
STANDINGS_OUTPUT=/tmp/buzzerboard-qa62-standings node scripts/issue66-standings-visual.mjs
HUB_OUTPUT=/tmp/buzzerboard-qa62-hub node scripts/issue70-home-visual.mjs --logo-evidence --playwright-logo-fetch
```

Точные пробы запускают локальный Vite Preview и блокируют внешний трафик. Только последний набор Hub разрешает статические SVG официального CDN. Все запросы спортивных данных заменены фикстурами. Для baseline используется тот же скрипт в checkout `ad9db22e2f562e9a72609e3b3830107f1e78ec39`. Хэши входов находятся в `data/input-sha256.json`.

`png/baseline/probes` хранит снимки семи дефектов до исправлений. `png/current` содержит повторные точные пробы, три регрессионных набора, Hub, Standings и общий визуальный прогон. Приложенные отчёты GitHub Actions и анонимные статусы Cloudflare Access не содержат сессий владельца и не подтверждают авторизованные данные.
